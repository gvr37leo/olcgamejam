class Vector {
    constructor(...vals) {
        this.vals = vals;
    }
    map(callback) {
        for (var i = 0; i < this.vals.length; i++) {
            callback(this.vals, i);
        }
        return this;
    }
    mul(v) {
        return this.map((arr, i) => arr[i] *= v.vals[i]);
    }
    div(v) {
        return this.map((arr, i) => arr[i] /= v.vals[i]);
    }
    floor() {
        return this.map((arr, i) => arr[i] = Math.floor(arr[i]));
    }
    ceil() {
        return this.map((arr, i) => arr[i] = Math.ceil(arr[i]));
    }
    round() {
        return this.map((arr, i) => arr[i] = Math.round(arr[i]));
    }
    add(v) {
        return this.map((arr, i) => arr[i] += v.vals[i]);
    }
    sub(v) {
        return this.map((arr, i) => arr[i] -= v.vals[i]);
    }
    scale(s) {
        return this.map((arr, i) => arr[i] *= s);
    }
    length() {
        var sum = 0;
        this.map((arr, i) => sum += arr[i] * arr[i]);
        return Math.pow(sum, 0.5);
    }
    normalize() {
        return this.scale(1 / this.length());
    }
    to(v) {
        return v.c().sub(this);
    }
    lerp(v, weight) {
        return this.c().add(this.to(v).scale(weight));
    }
    c() {
        return Vector.fromArray(this.vals.slice());
    }
    overwrite(v) {
        return this.map((arr, i) => arr[i] = v.vals[i]);
    }
    dot(v) {
        var sum = 0;
        this.map((arr, i) => sum += arr[i] * v.vals[i]);
        return sum;
    }
    angle2d(b) {
        return Math.acos(this.dot(b) / (this.length() + b.length()));
    }
    rotate2d(turns) {
        var radians = turns * Math.PI * 2;
        var cost = Math.cos(radians);
        var sint = Math.sin(radians);
        var x = this.x * cost - this.y * sint;
        var y = this.x * sint + this.y * cost;
        this.x = x;
        this.y = y;
        return this;
    }
    rotate3d(axis, radians) {
        var cost = Math.cos(radians);
        var sint = Math.sin(radians);
        var res = this.c().scale(cost);
        res.add(axis.cross(this).scale(sint));
        res.add(axis.c().scale(axis.dot(this) * (1 - cost)));
        this.overwrite(res);
        return this;
    }
    anglediff3d(v) {
        return Math.acos(this.dot(v) / (this.length() * v.length()));
    }
    projectOnto(v) {
        // https://www.youtube.com/watch?v=fjOdtSu4Lm4&list=PLImQaTpSAdsArRFFj8bIfqMk2X7Vlf3XF&index=1
        var vnormal = v.c().normalize();
        return vnormal.scale(this.dot(vnormal));
    }
    static reflect(normalout, vecin) {
        var vecout = vecin.c().scale(-1);
        var center = vecout.projectOnto(normalout);
        var vec2center = vecout.to(center);
        var refl = vecout.add(vec2center.scale(2));
        return refl;
    }
    wedge(v) {
        // https://www.youtube.com/watch?v=tjTRXzwdU6A&list=PLImQaTpSAdsArRFFj8bIfqMk2X7Vlf3XF&index=7
        return this.x * v.y - this.y * v.x;
    }
    //wedge can be used for collission detection
    //https://www.youtube.com/watch?v=tjTRXzwdU6A&list=PLImQaTpSAdsArRFFj8bIfqMk2X7Vlf3XF&index=8
    //1:18:06
    area(v) {
        return this.wedge(v) / 2;
    }
    loop(callback) {
        var counter = this.c();
        counter.vals.fill(0);
        while (counter.compare(this) == -1) {
            callback(counter);
            if (counter.incr(this)) {
                break;
            }
        }
    }
    compare(v) {
        for (var i = this.vals.length - 1; i >= 0; i--) {
            if (this.vals[i] < v.vals[i]) {
                continue;
            }
            else if (this.vals[i] == v.vals[i]) {
                return 0;
            }
            else {
                return 1;
            }
        }
        return -1;
    }
    incr(comparedTo) {
        for (var i = 0; i < this.vals.length; i++) {
            if ((this.vals[i] + 1) < comparedTo.vals[i]) {
                this.vals[i]++;
                return false;
            }
            else {
                this.vals[i] = 0;
            }
        }
        return true;
    }
    project(v) {
        return v.c().scale(this.dot(v) / v.dot(v));
    }
    get(i) {
        return this.vals[i];
    }
    set(i, val) {
        this.vals[i] = val;
    }
    get x() {
        return this.vals[0];
    }
    get y() {
        return this.vals[1];
    }
    get z() {
        return this.vals[2];
    }
    set x(val) {
        this.vals[0] = val;
    }
    set y(val) {
        this.vals[1] = val;
    }
    set z(val) {
        this.vals[2] = val;
    }
    draw(ctxt) {
        var width = 10;
        var halfwidth = width / 2;
        ctxt.fillRect(this.x - halfwidth, this.y - halfwidth, width, width);
    }
    cross(v) {
        var x = this.y * v.z - this.z * v.y;
        var y = this.z * v.x - this.x * v.z;
        var z = this.x * v.y - this.y * v.x;
        return new Vector(x, y, z);
    }
    static fromArray(vals) {
        var x = new Vector();
        x.vals = vals;
        return x;
    }
    loop2d(callback) {
        var counter = new Vector(0, 0);
        for (counter.x = 0; counter.x < this.x; counter.x++) {
            for (counter.y = 0; counter.y < this.y; counter.y++) {
                callback(counter);
            }
        }
    }
    loop3d(callback) {
        var counter = new Vector(0, 0, 0);
        for (counter.x = 0; counter.x < this.x; counter.x++) {
            for (counter.y = 0; counter.y < this.y; counter.y++) {
                for (counter.z = 0; counter.z < this.z; counter.z++) {
                    callback(counter);
                }
            }
        }
    }
}
// (window as any).devtoolsFormatters = [
//     {
//         header: function(obj, config){
//             if(!(obj instanceof Vector)){
//                 return null
//             }
//             if((obj.vals.length == 2)){
//                 return ["div",{style:""}, `x:${obj.x} y:${obj.y}`]
//             }
//             if((obj.vals.length == 3)){
//                 return ["div",{style:""}, `x:${obj.x} y:${obj.y} z:${obj.z}`]
//             }
//         },
//         hasBody: function(obj){
//             return false
//         },
//     }
// ]
class RNG {
    constructor(seed) {
        this.seed = seed;
        this.mod = 4294967296;
        this.multiplier = 1664525;
        this.increment = 1013904223;
    }
    next() {
        this.seed = (this.multiplier * this.seed + this.increment) % this.mod;
        return this.seed;
    }
    norm() {
        return this.next() / this.mod;
    }
    range(min, max) {
        return lerp(min, max, this.norm());
    }
    rangeFloor(min, max) {
        return Math.floor(this.range(min, max));
    }
    choose(arr) {
        return arr[this.rangeFloor(0, arr.length)];
    }
    shuffle(arr) {
        for (var end = arr.length; end > 0; end--) {
            swap(arr, this.rangeFloor(0, end), end);
        }
        return arr;
    }
}
class Store {
    constructor() {
        this.map = new Map();
        this.counter = 0;
    }
    get(id) {
        return this.map.get(id);
    }
    add(item) {
        item.id = this.counter++;
        this.map.set(item.id, item);
    }
    list() {
        return Array.from(this.map.values());
    }
    remove(id) {
        var val = this.map.get(id);
        this.map.delete(id);
        return val;
    }
}
var TAU = Math.PI * 2;
function map(val, from1, from2, to1, to2) {
    return lerp(to1, to2, inverseLerp(val, from1, from2));
}
function inverseLerp(val, a, b) {
    return to(a, val) / to(a, b);
}
function inRange(min, max, value) {
    if (min > max) {
        var temp = min;
        min = max;
        max = temp;
    }
    return value <= max && value >= min;
}
function min(a, b) {
    if (a < b)
        return a;
    return b;
}
function max(a, b) {
    if (a > b)
        return a;
    return b;
}
function clamp(val, min, max) {
    return this.max(this.min(val, max), min);
}
function rangeContain(a1, a2, b1, b2) {
    return max(a1, a2) >= max(b1, b2) && min(a1, a2) <= max(b1, b2);
}
function startMouseListen(localcanvas) {
    var mousepos = new Vector(0, 0);
    document.addEventListener('mousemove', (e) => {
        mousepos.overwrite(getMousePos(localcanvas, e));
    });
    return mousepos;
}
function getMousePos(canvas, evt) {
    var rect = canvas.getBoundingClientRect();
    return new Vector(evt.clientX - rect.left, evt.clientY - rect.top);
}
function createCanvas(x, y) {
    var canvas = document.createElement('canvas');
    canvas.width = x;
    canvas.height = y;
    document.body.appendChild(canvas);
    var ctxt = canvas.getContext('2d');
    return { ctxt: ctxt, canvas: canvas };
}
function random(min, max) {
    return Math.random() * (max - min) + min;
}
var lastUpdate = Date.now();
function loop(callback) {
    var now = Date.now();
    callback((now - lastUpdate) / 1000);
    lastUpdate = now;
    requestAnimationFrame(() => {
        loop(callback);
    });
}
function mod(number, modulus) {
    return ((number % modulus) + modulus) % modulus;
}
var keys = {};
document.addEventListener('keydown', (e) => {
    keys[e.key] = true;
});
document.addEventListener('keyup', (e) => {
    keys[e.key] = false;
});
function getMoveInput() {
    var dir = new Vector(0, 0);
    if (keys['a'])
        dir.x--; //left
    if (keys['w'])
        dir.y++; //up
    if (keys['d'])
        dir.x++; //right
    if (keys['s'])
        dir.y--; //down
    return dir;
}
function getMoveInputYFlipped() {
    var input = getMoveInput();
    input.y *= -1;
    return input;
}
function loadTextFiles(strings) {
    var promises = [];
    for (var string of strings) {
        var promise = fetch(string)
            .then(resp => resp.text())
            .then(text => text);
        promises.push(promise);
    }
    return Promise.all(promises);
}
function loadImages(urls) {
    var promises = [];
    for (var url of urls) {
        promises.push(new Promise((res, rej) => {
            var image = new Image();
            image.onload = e => {
                res(image);
            };
            image.src = url;
        }));
    }
    return Promise.all(promises);
}
function findbestIndex(list, evaluator) {
    if (list.length < 1) {
        return -1;
    }
    var bestIndex = 0;
    var bestscore = evaluator(list[0]);
    for (var i = 1; i < list.length; i++) {
        var score = evaluator(list[i]);
        if (score > bestscore) {
            bestscore = score;
            bestIndex = i;
        }
    }
    return bestIndex;
}
function lerp(a, b, r) {
    return a + to(a, b) * r;
}
function to(a, b) {
    return b - a;
}
function swap(arr, a = 0, b = 1) {
    var temp = arr[a];
    arr[a] = arr[b];
    arr[b] = temp;
}
function first(arr) {
    return arr[0];
}
function last(arr) {
    return arr[arr.length - 1];
}
function create2DArray(size, filler) {
    var result = new Array(size.y);
    for (var i = 0; i < size.y; i++) {
        result[i] = new Array(size.x);
    }
    size.loop2d(v => {
        result[v.y][v.x] = filler(v);
    });
    return result;
}
function get2DArraySize(arr) {
    return new Vector(arr[0].length, arr.length);
}
function index2D(arr, i) {
    return arr[i.x][i.y];
}
function copy2dArray(arr) {
    return create2DArray(get2DArraySize(arr), pos => index2D(arr, pos));
}
function round(number, decimals) {
    var mul = 10 ** decimals;
    return Math.round(number * mul) / mul;
}
var rng = new RNG(0);
function shuffle(array) {
    var currentIndex = array.length, temporaryValue, randomIndex;
    while (0 !== currentIndex) {
        randomIndex = Math.floor(rng.norm() * currentIndex);
        currentIndex -= 1;
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
    }
    return array;
}
function remove(arr, value) {
    var index = arr.indexOf(value);
    if (index > -1) {
        arr.splice(index, 1);
    }
    return arr;
}
class StopWatch {
    constructor() {
        this.starttimestamp = Date.now();
        this.pausetimestamp = Date.now();
        this.pausetime = 0;
        this.paused = true;
    }
    get() {
        var currentamountpaused = 0;
        if (this.paused) {
            currentamountpaused = to(this.pausetimestamp, Date.now());
        }
        return to(this.starttimestamp, Date.now()) - (this.pausetime + currentamountpaused);
    }
    start() {
        this.paused = false;
        this.starttimestamp = Date.now();
        this.pausetime = 0;
    }
    continue() {
        if (this.paused) {
            this.paused = false;
            this.pausetime += to(this.pausetimestamp, Date.now());
        }
    }
    pause() {
        if (this.paused == false) {
            this.paused = true;
            this.pausetimestamp = Date.now();
        }
    }
    reset() {
        this.paused = true;
        this.starttimestamp = Date.now();
        this.pausetimestamp = Date.now();
        this.pausetime = 0;
    }
}
class Rule {
    constructor(message, cb) {
        this.message = message;
        this.cb = cb;
    }
}
class Ability {
    constructor(cb) {
        this.cb = cb;
        // ammo:number = 1
        // maxammo:number = 1
        // ammorechargerate:number = 1000
        // casttime:number = 2000
        // channelduration:number = 3000
        this.cooldown = 1000;
        this.lastfire = Date.now();
        this.rules = [
            new Rule('not ready yet', () => (this.lastfire + this.cooldown) < Date.now()),
        ];
        this.stopwatch = new StopWatch();
        this.ventingtime = 0;
        this.onCastFinished = new EventSystem();
        this.shots = 0;
        this.firing = false;
    }
    //positive if you need to wait 0 or negative if you can call it
    timeTillNextPossibleActivation() {
        return to(Date.now(), this.lastfire + this.cooldown);
    }
    canActivate() {
        return this.rules.every(r => r.cb());
    }
    callActivate() {
        this.cb();
    }
    fire() {
        if (this.firing == false) {
            this.startfire();
        }
        else {
            this.holdfire();
        }
    }
    releasefire() {
        this.firing = false;
    }
    tapfire() {
        this.startfire();
        this.releasefire();
    }
    startfire() {
        if (this.rules.some(r => r.cb())) {
            this.firing = true;
            this.ventingtime = 0;
            this.stopwatch.start();
            this.ventingtime -= this.cooldown;
            this.shots = 1;
            this.lastfire = Date.now();
            this.cb();
        }
    }
    holdfire() {
        this.ventingtime += this.stopwatch.get();
        this.stopwatch.start();
        this.shots = Math.ceil(this.ventingtime / this.cooldown);
        this.ventingtime -= this.shots * this.cooldown;
        this.lastfire = Date.now();
        if (this.shots > 0) {
            this.cb();
        }
    }
}
var AnimType;
(function (AnimType) {
    AnimType[AnimType["once"] = 0] = "once";
    AnimType[AnimType["repeat"] = 1] = "repeat";
    AnimType[AnimType["pingpong"] = 2] = "pingpong";
    AnimType[AnimType["extend"] = 3] = "extend";
})(AnimType || (AnimType = {}));
class Anim {
    constructor() {
        this.animType = AnimType.once;
        this.reverse = false;
        this.duration = 1000;
        this.stopwatch = new StopWatch();
        this.begin = 0;
        this.end = 1;
    }
    get() {
        var cycles = this.stopwatch.get() / this.duration;
        switch (this.animType) {
            case AnimType.once:
                return clamp(lerp(this.begin, this.end, cycles), this.begin, this.end);
            case AnimType.repeat:
                return lerp(this.begin, this.end, mod(cycles, 1));
            case AnimType.pingpong:
                var pingpongcycle = mod(cycles, 2);
                if (pingpongcycle <= 1) {
                    return lerp(this.begin, this.end, pingpongcycle);
                }
                else {
                    return lerp(this.end, this.begin, pingpongcycle - 1);
                }
            case AnimType.extend:
                var distPerCycle = to(this.begin, this.end);
                return Math.floor(cycles) * distPerCycle + lerp(this.begin, this.end, mod(cycles, 1));
        }
    }
}
class Rect {
    constructor(min, max) {
        this.min = min;
        this.max = max;
    }
    static fromsize(pos, size) {
        return new Rect(pos.c(), pos.c().add(size));
    }
    static fromCenter(center, size) {
        var halfsize = size.c().scale(0.5);
        var pos = center.c().sub(halfsize);
        return new Rect(pos.c(), pos.c().add(size));
    }
    collidePoint(point) {
        for (var i = 0; i < this.min.vals.length; i++) {
            if (!inRange(this.min.vals[i], this.max.vals[i], point.vals[i])) {
                return false;
            }
        }
        return true;
    }
    size() {
        return this.min.to(this.max);
    }
    collideBox(other) {
        var x = rangeOverlap(this.min.x, this.max.x, other.min.x, other.max.x);
        var y = rangeOverlap(this.min.y, this.max.y, other.min.y, other.max.y);
        return x && y;
    }
    getPoint(relativePos) {
        return this.min.c().add(this.size().mul(relativePos));
    }
    draw(ctxt) {
        var size = this.size();
        ctxt.fillRect(this.min.x, this.min.y, size.x, size.y);
    }
    moveTo(pos) {
        var size = this.size();
        this.min = pos.c();
        this.max = this.min.c().add(size);
    }
    moveToCentered(pos) {
        var halfsize = this.size().scale(0.5);
        this.moveTo(pos.c().sub(halfsize));
    }
    loop(callback) {
        var temp = this.max.c();
        this.size().loop(v2 => {
            temp.overwrite(v2);
            temp.add(this.min);
            callback(temp);
        });
    }
}
function rangeOverlap(range1A, range1B, range2A, range2B) {
    return range1A <= range2B && range2A <= range1B;
}
class EventQueue {
    constructor() {
        this.idcounter = 0;
        this.onProcessFinished = new EventSystem();
        this.onRuleBroken = new EventSystem();
        this.rules = [];
        this.discoveryidcounter = 0;
        this.listeners = [];
        this.events = [];
    }
    // listenDiscovery(type:string,megacb:(data:any,cb:(cbdata:any) => void) => void){
    //     this.listen(type,(dataAndCb:{data:any,cb:(ads:any) => void}) => {
    //         megacb(dataAndCb.data,dataAndCb.cb)
    //     })
    // }
    // startDiscovery(type:string,data: any, cb: (cbdata: any) => void) {
    //     this.addAndTrigger(type,{data,cb})
    // }
    listenDiscovery(type, cb) {
        this.listen(type, (discovery) => {
            cb(discovery.data, discovery.id);
        });
    }
    startDiscovery(type, data, cb) {
        let createdid = this.discoveryidcounter++;
        let listenerid = this.listen('completediscovery', (discovery) => {
            if (discovery.data.id == createdid) {
                this.unlisten(listenerid);
                cb(discovery.data.data);
            }
        });
        this.addAndTrigger(type, { data, id: createdid });
    }
    completeDiscovery(data, id) {
        this.addAndTrigger('completediscovery', { data, id });
    }
    listen(type, cb) {
        var id = this.idcounter++;
        this.listeners.push({
            id: id,
            type: type,
            cb,
        });
        return id;
    }
    listenOnce(type, cb) {
        let id = this.listen(type, (data) => {
            this.unlisten(id);
            cb(data);
        });
        return id;
    }
    unlisten(id) {
        var index = this.listeners.findIndex(o => o.id == id);
        this.listeners.splice(index, 1);
    }
    process() {
        while (this.events.length > 0) {
            let currentEvent = this.events.shift();
            let listeners = this.listeners.filter(l => l.type == currentEvent.type);
            let brokenrules = this.rules.filter(r => r.type == currentEvent.type && r.rulecb(currentEvent.data) == false);
            if (brokenrules.length == 0) {
                for (let listener of listeners) {
                    listener.cb(currentEvent.data);
                }
            }
            else {
                console.log(first(brokenrules).error);
                this.onRuleBroken.trigger({ event: currentEvent, error: first(brokenrules).error });
            }
        }
        this.onProcessFinished.trigger(0);
    }
    add(type, data) {
        this.events.push({
            type: type,
            data: data,
        });
    }
    addAndTrigger(type, data) {
        this.add(type, data);
        this.process();
    }
    addRule(type, error, rulecb) {
        this.rules.push({ type, error, rulecb });
    }
}
class EventSystem {
    constructor() {
        this.idcounter = 0;
        this.listeners = [];
    }
    listen(cb) {
        var listener = {
            id: this.idcounter++,
            cb: cb,
        };
        this.listeners.push(listener);
        return listener.id;
    }
    unlisten(id) {
        var index = this.listeners.findIndex(o => o.id == id);
        this.listeners.splice(index, 1);
    }
    trigger(val) {
        for (var listener of this.listeners) {
            listener.cb(val);
        }
    }
}
class Camera {
    constructor(ctxt) {
        this.ctxt = ctxt;
        this.pos = new Vector(0, 0);
        this.scale = new Vector(1, 1);
    }
    begin() {
        ctxt.save();
        var m = this.createMatrixScreen2World().inverse();
        ctxt.transform(m.a, m.b, m.c, m.d, m.e, m.f);
    }
    end() {
        ctxt.restore();
    }
    createMatrixScreen2World() {
        var a = new DOMMatrix([
            1, 0, 0, 1, -screensize.x / 2, -screensize.y / 2
        ]);
        var b = new DOMMatrix([
            this.scale.x, 0, 0, this.scale.y, this.pos.x, this.pos.y
        ]);
        return b.multiply(a);
    }
    screen2world(pos) {
        var dompoint = this.createMatrixScreen2World().transformPoint(new DOMPoint(pos.x, pos.y));
        return new Vector(dompoint.x, dompoint.y);
    }
    world2screen(pos) {
        var dompoint = this.createMatrixScreen2World().inverse().transformPoint(new DOMPoint(pos.x, pos.y));
        return new Vector(dompoint.x, dompoint.y);
    }
}
class NetEntity {
    constructor(init) {
        this.id = null;
        this.parent = null;
        this.type = '';
        this.name = '';
        this.children = [];
        // ordercount = 0
        // sortorder = 0
        this.synced = false;
        Object.assign(this, init);
        this.type = 'entity';
    }
    setChild(child) {
        //remove child from old parent
        var oldparent = NetEntity.globalEntityStore.get(child.parent);
        if (oldparent != null) {
            remove(oldparent.children, child.id);
        }
        this.children.push(child.id);
        child.parent = this.id;
        // child.sortorder = this.ordercount++
    }
    setParent(parent) {
        if (parent == null) {
            this.parent = null;
        }
        else {
            parent.setChild(this);
        }
    }
    getParent() {
        return NetEntity.globalEntityStore.get(this.parent);
    }
    descendant(cb) {
        return this.descendants(cb)[0];
    }
    descendants(cb) {
        var children = this._children(cb);
        var grandchildren = children.flatMap(c => c.descendants(cb));
        return children.concat(grandchildren);
    }
    child(cb) {
        return this._children(cb)[0];
    }
    _children(cb) {
        return this.children.map(id => NetEntity.globalEntityStore.get(id)).filter(cb);
    }
    allChildren() {
        return this._children(() => true);
    }
    remove() {
        remove(this.getParent().children, this.id);
        NetEntity.globalEntityStore.remove(this.id);
        this.removeChildren();
        return this;
    }
    inject(parent) {
        NetEntity.globalEntityStore.add(this);
        this.setParent(parent);
        return this;
    }
    removeChildren() {
        this.descendants(() => true).forEach(e => NetEntity.globalEntityStore.remove(e.id));
        this.children = [];
    }
    ancestor(cb) {
        var current = this;
        while (current != null && cb(current) == false) {
            current = NetEntity.globalEntityStore.get(current.parent);
        }
        return current;
    }
}
/*
class ServerClient{
    
    output = new EventSystem<any>()
    sessionid: number = null

    constructor(public socket, public id){


        this.socket.on('message',(data) => {
            this.output.trigger(data)
        })
    }

    input(type,data){
        this.socket.emit('message',{type,data})
    }
}

class Server{
    // gamemanager: GameManager;
    output = new EventSystem<{type:string,data:any}>()
    clients = new Store<ServerClient>()
    sessionidcounter = 0

    onBroadcast = new EventSystem<{type:string,data:any}>()

    constructor(){
        this.gamemanager = new GameManager()
        Entity.globalEntityStore = this.gamemanager.entityStore;

        this.gamemanager.setupListeners()
        this.gamemanager.eventQueue.addAndTrigger('init',null)

        this.gamemanager.eventQueue.onProcessFinished.listen(() => {
            this.updateClients()
            set synced status of updated entities to true
        })

        this.gamemanager.broadcastEvent.listen((event) => {
            for(var client of this.clients.list()){
                client.input(event.type,event.data)
            }
        })

        this.gamemanager.sendEvent.listen((event) => {
            this.clients.list().filter(c => c.sessionid == event.sessionid).forEach(c => c.input(event.type,event.data))
        })

        setInterval(() => {
            var longdcedplayers = this.gamemanager.helper.getPlayers().filter(p => p.disconnected == true && (Date.now() - p.dctimestamp) > 5_000 )
            longdcedplayers.forEach(p => {
                console.log(`removed disconnected player:${p.name}`)
                p.remove()
            })
            if(longdcedplayers.length > 0){
                this.updateClients()
            }
        },5000)
    }

    updateClients(){
        this.gamemanager.broadcastEvent.trigger({type:'update',data:this.gamemanager.entityStore.list()})
    }

    connect(client:ServerClient){
        this.clients.add(client)
        let players = this.gamemanager.helper.getPlayers()

        //client does a handshake
        //if client sends sessionID look for a player with that sessionid
        //if not found or client sends no sessionid create a new player with a new sessionid
        //finish handshake by sending client and sessionid
        //when a client disconnects flag player as dc'ed and set dc timestamp after 2 min delete dc'ed players

        //client should connect, check for sessionid in localstore/sessionstorage
        //then initiate handshake send found sessionid
        //save session and client id on client and look in database for player with sessionid = client.sessionid
        client.socket.on('handshake',(data,fn) => {
            
            let sessionid = data.sessionid
            if(sessionid == null){
               sessionid = this.sessionidcounter++
            }
            this.sessionidcounter = Math.max(sessionid,this.sessionidcounter)//should create random guid instead
            client.sessionid = sessionid
            console.log(`user connected:${client.sessionid}`)

            let foundplayer = players.find(p => p.sessionid == sessionid)
            if(foundplayer == null){
                let player = new Player({clientid:client.id,sessionid:sessionid})
                player.inject(this.gamemanager.helper.getPlayersNode())
                
            }else{
                foundplayer.clientid = client.id
                foundplayer.disconnected = false
                //reconnection dont create new player but do change the pointer to the new client
            }

            fn({
                clientid:client.id,
                sessionid:sessionid,
            })
            this.updateClients()
        })

        
        

        client.socket.on('disconnect',() => {
            //watch out for multiple connected clients
            this.clients.remove(client.id)
            var sessionplayer = this.gamemanager.helper.getSessionPlayer(client.sessionid)
            console.log(`user disconnected:${client.sessionid}`)
            //this often goes wrong for some reason
            //maybe when multiple clients are connected the old player's clientid gets overwritten
            //also goes wrong when a second tab connects and disconnects
            // check if other clients use the same sessionid
            
            var connectedclients = this.clients.list().filter(c => c.sessionid == client.sessionid)
            if(connectedclients.length == 0){
                sessionplayer.disconnected = true
                sessionplayer.dctimestamp = Date.now()
            }
            
            this.updateClients()
        })

        client.output.listen(e => {
            server.input(e.type,{clientid:client.id,sessionid:client.sessionid,data:e.data})
        })
    }

    input(type,data){
        this.gamemanager.eventQueue.addAndTrigger(type,data)
    }

    serialize(){
        //only serialize unsynced entitys
        return JSON.stringify(this.gamemanager.entityStore.list())
    }

    
}

*/ 
var contextStack = [[document.body]];
function currentContext() {
    return last(contextStack);
}
function startContext(element) {
    contextStack.push([element]);
}
function endContext() {
    contextStack.pop();
}
function scr(tag, attributes = {}) {
    flush();
    return cr(tag, attributes);
}
function cr(tag, attributes = {}) {
    var parent = peek();
    var element = document.createElement(tag);
    if (parent) {
        parent.appendChild(element);
    }
    for (var key in attributes) {
        element.setAttribute(key, attributes[key]);
    }
    currentContext().push(element);
    return element;
}
function crend(tag, textstring, attributes = {}) {
    cr(tag, attributes);
    text(textstring);
    return end();
}
function text(data) {
    peek().textContent = data;
    return peek();
}
function html(html) {
    peek().innerHTML = html;
}
function end(endelement = null) {
    var poppedelement = currentContext().pop();
    if (endelement != null && endelement != poppedelement) {
        console.warn(poppedelement, ' doesnt equal ', endelement);
    }
    return poppedelement;
}
HTMLElement.prototype.on = function (event, cb) {
    this.addEventListener(event, cb);
    return this;
};
function peek() {
    var context = currentContext();
    return last(context);
}
function flush() {
    var context = currentContext();
    var root = context[0];
    context.length = 0;
    return root;
}
function div(options = {}) {
    return cr('div', options);
}
function a(options = {}) {
    return cr('a', options);
}
function button(text, options = {}) {
    return crend('button', text, options);
}
function input(options = {}) {
    return crend('input', options);
}
function img(options = {}) {
    return crend('img', options);
}
function stringToHTML(str) {
    var temp = document.createElement('template');
    temp.innerHTML = str;
    return temp.content.firstChild;
}
function upsertChild(parent, child) {
    if (parent.firstChild) {
        parent.replaceChild(child, parent.firstChild);
    }
    else {
        parent.appendChild(child);
    }
}
function qs(element, query) {
    if (typeof element == 'string') {
        return document.body.querySelector(element);
    }
    return element.querySelector(query);
}
function qsa(element, query) {
    return Array.from(element.querySelectorAll(query));
}
function initBits(pos, array, vertical = false, start = 0, end = -1) {
    if (end == -1) {
        end = array.length;
    }
    pos = pos.c();
    var res = [];
    for (var i = start; i < array.length && i < end; i++) {
        entitys.push(new Entity({
            pos: pos.c(),
            rect: Rect.fromsize(pos, tilesize),
            type: 'bit',
            updatecb(self) {
            },
            drawcb(self) {
                var bit = self.data;
                ctxt.textAlign = 'center';
                ctxt.textBaseline = 'middle';
                ctxt.font = '30px Arial';
                ctxt.fillStyle = bit.get() ? 'white' : 'black';
                fillRect(self.pos, tilesize);
                ctxt.fillStyle = bit.get() ? 'black' : 'white';
                ctxt.fillText(bit.get().toString(), self.pos.x + halfsize.x, self.pos.y + halfsize.y + 3);
            },
            data: new Bit({
                array,
                index: i,
            })
        }));
        if (vertical) {
            pos.y += tilesize.y;
        }
        else {
            pos.x += tilesize.x;
        }
        res.push(last(entitys));
    }
    return res;
}
function fillRect(pos, size, centered = false) {
    if (centered) {
        pos = pos.c().sub(size.c().scale(0.5));
    }
    ctxt.fillRect(pos.x, pos.y, size.x + 1, size.y + 1);
}
class Particle {
    constructor(data) {
        Object.assign(this, data);
    }
}
function spawnBitParticles(pos) {
    var lifespan = 2;
    for (var i = 0; i < 20; i++) {
        entitys.push(new Entity({
            pos: pos.c(),
            createdAt: time,
            updatecb: (self) => {
                var particle = self.data;
                particle.vel.add(particle.acc.c().scale(globaldt));
                self.pos.add(particle.vel.c().scale(globaldt));
                var age = to(self.createdAt, time);
                if (age > lifespan) {
                    self.markedForDeletion = true;
                }
            },
            drawcb: (self) => {
                var age = to(self.createdAt, time);
                var completion = inverseLerp(age, 0, lifespan);
                ctxt.fillStyle = 'white';
                ctxt.font = '16px Arial';
                ctxt.globalAlpha = 1 - tween(completion, 0, 0);
                ctxt.fillText(self.data.text, self.pos.x, self.pos.y);
            },
            data: new Particle({
                vel: new Vector(rng.range(-50, 50), rng.range(-50, 50)),
                acc: new Vector(0, 0),
                text: rng.choose(['0', '1']),
            })
        }));
    }
}
function spawnFireParticles(pos, vel) {
    var lifespan = 2;
    for (var i = 0; i < 20; i++) {
        entitys.push(new Entity({
            pos: pos.c(),
            createdAt: time,
            updatecb: (self) => {
                var particle = self.data;
                particle.vel.add(particle.acc.c().scale(globaldt));
                self.pos.add(particle.vel.c().scale(globaldt));
                var age = to(self.createdAt, time);
                if (age > lifespan) {
                    self.markedForDeletion = true;
                }
            },
            drawcb: (self) => {
                var age = to(self.createdAt, time);
                var completion = inverseLerp(age, 0, lifespan);
                ctxt.globalAlpha = 1 - tween(completion, 0, 0);
                drawAnimation(self.pos, fireballAnimation, time);
            },
            data: new Particle({
                vel: new Vector(rng.range(-50, 50), rng.range(-20, 20)).add(vel.c().scale(0.2)),
                acc: new Vector(0, -50),
            })
        }));
    }
}
function collissionCheck(rect, type) {
    return collissionCheckWorld(rect) || collisionCheckEntitys(rect, type);
}
function collissionCheckWorld(rect) {
    var _a;
    var tl = rect.getPoint(new Vector(0, 0)).div(tilesize).floor();
    var br = rect.getPoint(new Vector(1, 1)).div(tilesize).floor();
    for (var layer of tiledmap.layers) {
        if (layer.type == 'objectgroup') {
            continue;
        }
        for (var x = tl.x; x <= br.x; x++) {
            for (var y = tl.y; y <= br.y; y++) {
                if (x < 0 || y < 0) {
                    continue;
                }
                var gid = layer.data[y * layer.width + x];
                if (gid == 0 || gid == undefined) {
                    continue;
                }
                var { lid, tileset } = gid2local(gid, tiledmap.tilesets);
                if ((_a = tileset.tilesdict[lid]) === null || _a === void 0 ? void 0 : _a.isSolid) {
                    return true;
                }
            }
        }
    }
    return false;
}
function collisionCheckEntitys(rect, type) {
    var fentitys = entitys.filter(e => e.type == type);
    for (var entity of fentitys) {
        if (entity.rect.collideBox(rect)) {
            return entity;
        }
    }
    return null;
}
function rotStart(center, turns) {
    ctxt.save();
    ctxt.translate(center.x, center.y);
    ctxt.rotate(turns * TAU);
    ctxt.translate(-center.x, -center.y);
}
function rotEnd() {
    ctxt.restore();
}
function drawImage(image, pos, size, centered = false) {
    if (centered) {
        pos = pos.c().sub(halfsize);
    }
    ctxt.drawImage(image, pos.x, pos.y, size.x + 1, size.y + 1);
}
function drawImage2(image, src, dst) {
    var srcsize = src.size();
    var dstsize = dst.size();
    ctxt.drawImage(image, src.min.x, src.min.y, srcsize.x, srcsize.y, dst.min.x - 0.5, dst.min.y - 0.5, dstsize.x + 1, dstsize.y + 1);
}
function loadImage(src) {
    var image = new Image();
    image.src = src;
    return image;
}
function index2Vector(index, width) {
    return new Vector(index % width, Math.floor(index / width));
}
function vector2index(v, width) {
    return v.y * width + v.x;
}
function tween(x, a, b) {
    return (a + b - 2) * x * x * x + (3 - 2 * a - b) * x * x + a * x;
}
class Bit {
    constructor(data) {
        Object.assign(this, data);
    }
    get() {
        return this.array[this.index];
    }
    set(val) {
        this.array[this.index] = val;
    }
    flip() {
        this.set(1 - this.get());
    }
}
class Enemy {
    constructor(incdata) {
        this.data = [];
        this.attackcd = new Cooldown(1);
        this.props = [
            new Prop({
                name: 'damage',
                size: 4,
            }),
            new Prop({
                name: 'speed',
                size: 4,
            }),
            new Prop({
                name: 'health',
                size: 6,
            }),
        ];
        Object.assign(this, incdata);
        this.data = new Array(12);
        for (var key in incdata) {
            this.setProp(key, incdata[key]);
        }
    }
    setProp(name, value) {
        var offset = 0;
        for (var prop of this.props) {
            if (prop.name == name) {
                var bits = number2Bits(value, prop.size);
                this.data.splice(offset, prop.size, ...bits);
            }
            offset += prop.size;
        }
    }
    getProp(name) {
        var offset = 0;
        for (var prop of this.props) {
            if (prop.name == name) {
                var bits = this.data.slice(offset, offset + prop.size);
                return bits2Number(bits);
            }
            offset += prop.size;
        }
    }
}
class Cooldown {
    constructor(maxcooldown) {
        this.cooldown = 0;
        this.maxcooldown = maxcooldown;
    }
    isready() {
        return this.cooldown <= 0;
    }
    tryfire() {
        if (this.isready()) {
            this.cooldown = this.maxcooldown;
            return true;
        }
        return false;
    }
    update(dt) {
        this.cooldown -= dt;
        if (this.cooldown < 0) {
            this.cooldown = 0;
        }
    }
}
class Prop {
    constructor(data) {
        Object.assign(this, data);
    }
}
class Gun {
    constructor(incdata) {
        this.data = [];
        this.props = [
            new Prop({
                name: 'ammo',
                size: 8,
            }),
            new Prop({
                name: 'firerate',
                size: 4,
            }),
        ];
        this.data = new Array(12);
        for (var key in incdata) {
            this.setProp(key, incdata[key]);
        }
    }
    inc(name) {
        this.setProp(name, this.getProp(name) + 1);
    }
    decr(name) {
        this.setProp(name, this.getProp(name) - 1);
    }
    setProp(name, value) {
        this[name] = value;
        var offset = 0;
        for (var prop of this.props) {
            if (prop.name == name) {
                var bits = number2Bits(value, prop.size);
                this.data.splice(offset, prop.size, ...bits);
            }
            offset += prop.size;
        }
    }
    getProp(name) {
        var offset = 0;
        for (var prop of this.props) {
            if (prop.name == name) {
                var bits = this.data.slice(offset, prop.size);
                return bits2Number(bits);
            }
            offset += prop.size;
        }
    }
}
function number2Bits(number, maxbits) {
    var res = [];
    for (var i = 0; i < maxbits; i++) {
        res.unshift(number % 2 === 1 ? 1 : 0);
        number = Math.floor(number / 2);
    }
    return res;
}
function bits2Number(bits) {
    var res = 0;
    for (var i = bits.length - 1, j = 0; i >= 0; i--, j++) {
        if (bits[i] == 1) {
            res += Math.pow(2, j);
        }
    }
    return res;
}
class Entity {
    constructor(data) {
        this.markedForDeletion = false;
        Object.assign(this, data);
    }
}
class SpriteAnimation {
    constructor(data) {
        Object.assign(this, data);
    }
}
function drawAnimation(pos, animation, time, flipx = false, centered = true) {
    if (centered) {
        pos = pos.c().sub(animation.spritesize.c().scale(0.5));
    }
    var frame = Math.floor(map(time % animation.duration, 0, animation.duration, 0, animation.framecount));
    if (flipx) {
        var center = pos.c().add(animation.spritesize.c().scale(0.5));
        ctxt.save();
        ctxt.translate(center.x, center.y);
        ctxt.scale(-1, 1);
        ctxt.translate(-center.x, -center.y);
    }
    drawAtlasImage(pos, animation.startpos.c().add(animation.direction.c().scale(frame)), animation.spritesize, animation.imageatlas);
    if (flipx) {
        ctxt.restore();
    }
}
function drawAtlasImage(absdstpos, srctile, tilesize, image) {
    var abssrc = srctile.c().mul(tilesize);
    ctxt.drawImage(image, abssrc.x, abssrc.y, tilesize.x, tilesize.y, absdstpos.x, absdstpos.y, tilesize.x, tilesize.y);
}
class Player {
    constructor(data) {
        this.isDead = false;
        this.health = 1;
        this.inBitWorld = false;
        this.guncooldown = new Cooldown(0.1);
        this.gun = new Gun({
            ammo: 0b1111,
            firerate: 0b0100,
            bulletspeed: 0b100,
        });
        Object.assign(this, data);
    }
}
function playercb(self) {
    self.data.guncooldown.update(globaldt);
    if (mousebuttonsPressed[0] && player.data.gun.getProp('ammo') > 0 && self.data.guncooldown.tryfire()) {
        player.data.gun.decr('ammo');
        if (player.data.inBitWorld) {
            lasersound.play();
        }
        else {
            fireballsound.play();
        }
        var mouse = camera.screen2world(mousepos);
        var bulletspeed = 400;
        entitys.push(new Entity({
            pos: player.pos.c(),
            type: 'bullet',
            createdAt: time,
            updatecb(self) {
                var age = to(self.createdAt, time);
                if (age > 2) {
                    self.markedForDeletion = true;
                    return;
                }
                self.pos.add(self.data.vel.c().scale(globaldt));
                var bulletrect = Rect.fromCenter(self.pos, new Vector(5, 5));
                var hitbit = collisionCheckEntitys(bulletrect, 'bit');
                var hitenemy = collisionCheckEntitys(bulletrect, 'enemy');
                if (collissionCheckWorld(bulletrect)) {
                    self.markedForDeletion = true;
                }
                if (hitbit) {
                    self.markedForDeletion = true;
                    hitbit.data.flip();
                }
                if (hitenemy) {
                    hitenemy.data.setProp('health', hitenemy.data.getProp('health') - 1); //todo use gun damage 
                    self.markedForDeletion = true;
                    if (hitenemy.data.getProp('health') <= 0) {
                        hitenemy.markedForDeletion = true;
                        //spawnparticles
                        //play sound
                    }
                }
                if (self.markedForDeletion) {
                    if (self.data.isBitBullet) {
                        spawnBitParticles(self.pos);
                    }
                    else {
                        spawnFireParticles(self.pos, self.data.vel);
                    }
                }
            },
            drawcb(self) {
                if (self.data.isBitBullet) {
                    ctxt.font = '30px Arial';
                    ctxt.fillStyle = 'white';
                    ctxt.fillText('!', self.pos.x, self.pos.y);
                }
                else {
                    ctxt.fillStyle = 'red';
                    drawAnimation(self.pos, fireballAnimation, time, false, true);
                    // fillRect(self.pos,new Vector(5,5),true)
                }
            },
            data: {
                vel: player.pos.to(mouse).normalize().scale(bulletspeed),
                isBitBullet: player.data.inBitWorld
            }
        }));
        //tryshoot
        //start cooldown
        //spawn bullet
        //set if bullet is real or in bitworld
        //
    }
}
function renderTiled(tiledData) {
    //now the code is looping over all the id's
    //optimization could be only loop over visible tiles
    var tl = camera.screen2world(new Vector(0, 0)).div(tiledData.tilesize).floor();
    var br = camera.screen2world(screensize).div(tiledData.tilesize).floor();
    tl.x = max(0, tl.x);
    tl.y = max(0, tl.y);
    br.x = min(tiledData.size.x - 1, br.x);
    br.y = min(tiledData.size.y - 1, br.y);
    for (var x = tl.x; x <= br.x; x++) {
        for (var y = tl.y; y <= br.y; y++) {
            var index = y * tiledData.size.x + x;
            for (var layer of tiledData.layers) {
                if (layer.data) {
                    var gid = layer.data[index];
                    if (gid == 0) {
                        continue;
                    }
                    var FLIPPED_HORIZONTALLY_FLAG = 0x80000000;
                    var FLIPPED_VERTICALLY_FLAG = 0x40000000;
                    var FLIPPED_DIAGONALLY_FLAG = 0x20000000;
                    var ROTATED_HEXAGONAL_120_FLAG = 0x10000000;
                    var horflag = gid & FLIPPED_HORIZONTALLY_FLAG;
                    var verflag = gid & FLIPPED_VERTICALLY_FLAG;
                    var diagflag = gid & FLIPPED_DIAGONALLY_FLAG;
                    var hexflag = gid & ROTATED_HEXAGONAL_120_FLAG;
                    gid &= ~(FLIPPED_HORIZONTALLY_FLAG |
                        FLIPPED_VERTICALLY_FLAG |
                        FLIPPED_DIAGONALLY_FLAG |
                        ROTATED_HEXAGONAL_120_FLAG);
                    //gid first 4 bits are flags
                    var { lid, tileset } = gid2local(gid, tiledData.tilesets);
                    var tile = tileset.tilesdict[lid];
                    if (tile === null || tile === void 0 ? void 0 : tile.animation) {
                        var animduration = tile.animation.reduce((p, c) => p + c.duration, 0) / 1000;
                        var localtime = time % animduration;
                        var frame = Math.floor(localtime / 0.1);
                        lid = tile.animation[frame].tileid;
                    }
                    var srcabspos = index2Vector(lid, tileset.columns).mul(tileset.tilesize);
                    var dstabspos = index2Vector(index, tiledData.size.x).mul(tileset.tilesize);
                    var srcrect = Rect.fromsize(srcabspos, tileset.tilesize);
                    var dstrect = Rect.fromsize(dstabspos, tileset.tilesize);
                    // if(horflag){
                    //     srcrect.width *= -1
                    // }
                    // if(verflag){
                    //     srcrect.height *= -1
                    // }
                    // if(diagflag){
                    //     //todo, have to do some wizarding shit with custom defined vertices and uvs
                    // }
                    drawImage2(tileset.texture, srcrect, dstrect);
                }
                if (layer.objects) {
                    for (var object of layer.objects) {
                        if (object.text) {
                            ctxt.fillStyle = 'black';
                            ctxt.font = '30px Arial';
                            ctxt.fillText(object.text.text, object.x, object.y);
                        }
                        else {
                            if (drawdebuggraphics) {
                                ctxt.fillStyle = 'green';
                                fillRect(object.pos, tiledData.tilesize, true);
                            }
                        }
                    }
                }
            }
        }
    }
}
function preprocessTiledMap(tiledmap) {
    var _a;
    tiledmap.tilesize = new Vector(tiledmap.tilewidth, tiledmap.tileheight);
    tiledmap.size = new Vector(tiledmap.width, tiledmap.height);
    for (var layer of tiledmap.layers) {
        if (layer.data) {
            layer.backup = layer.data.slice();
        }
        if (layer.objects) {
            for (var object of layer.objects) {
                object.pos = new Vector(object.x, object.y);
                object.size = new Vector(object.width, object.height);
                embedProperties(object);
            }
        }
    }
    for (var tileset of tiledmap.tilesets) {
        tileset.texture = loadImage(tileset.image);
        tileset.tilesdict = {};
        tileset.tilesize = new Vector(tileset.tilewidth, tileset.tileheight);
        for (var tile of (_a = tileset.tiles) !== null && _a !== void 0 ? _a : []) {
            tileset.tilesdict[tile.id] = tile;
            embedProperties(tile);
        }
    }
}
function gid2local(gid, tilesets) {
    for (var i = tilesets.length - 1; i >= 0; i--) {
        if (tilesets[i].firstgid <= gid) {
            return {
                tileset: tilesets[i],
                lid: gid - tilesets[i].firstgid
            };
        }
    }
}
function embedProperties(object) {
    if (object.properties) {
        for (var prop of object.properties) {
            object[prop.name] = prop.value;
        }
    }
}
// var level1memory1 = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
// var level1memory2 = [1,1,1,1,1,1,1,1,1,1,1]
// var level1memory3 = [1,1,1,1,1,1,1,1,1,1,1]
// var level1memory4 = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
// var level1memory5 = [1,1,1,1,1,1,1,1,1,1,1]
function loadLevel1() {
    //have 5 arrays of memory
    //corresponding to the 5 walls in game
    loadWallsIntoBits(findObjectWithName('mark1').pos, findObjectWithName('mark2').pos, findObjectWithName('ref1').pos, 348, 1);
    movePlayerToSpawn();
    loadTeleports();
    loadFlags();
    entitys.push(new Entity({
        updatecb(self) {
            player.data.gun.setProp('ammo', 6);
        },
    }));
}
function movePlayerToSpawn() {
    player.pos = findObjectsOfType('spawn')[0].pos.c();
}
function loadTeleports() {
    var tpcooldown = new Cooldown(4);
    for (let object of findObjectsOfType('teleporter')) {
        entitys.push(new Entity({
            type: 'teleporter',
            pos: object.pos.c(),
            rect: Rect.fromCenter(object.pos.c(), tilesize),
            updatecb(self) {
                tpcooldown.update(globaldt);
                if (player.rect.collideBox(self.rect) && tpcooldown.tryfire()) {
                    teleportsound.play();
                    player.pos = findObjectWithId(object.dst).pos.c();
                    player.rect.moveToCentered(player.pos);
                    player.data.inBitWorld = !player.data.inBitWorld;
                    if (player.data.inBitWorld) {
                        bitmusic.play();
                        normalmusic.pause();
                    }
                    else {
                        bitmusic.pause();
                        normalmusic.play();
                    }
                }
            },
            drawcb(self) {
                drawAtlasImage(self.pos.c().sub(halfsize), new Vector(1, 2), tilesize, memoryimage);
            },
        }));
    }
}
function loadFlags() {
    var res = [];
    for (let flagobject of findObjectsOfType('flag')) {
        let flagpos = flagobject.pos;
        entitys.push(new Entity({
            type: 'flag',
            pos: flagpos,
            rect: Rect.fromCenter(flagpos, tilesize),
            updatecb(self) {
                if (self.data.isMenuFlag) {
                    if (self.data.enabled && self.rect.collideBox(player.rect)) {
                        switchLevel(self.data.dstlevel);
                        levelunlocked[self.data.dstlevel] = true;
                    }
                }
                else if (self.rect.collideBox(player.rect)) {
                    switchLevel(self.data.dstlevel);
                    levelunlocked[self.data.dstlevel] = true;
                }
            },
            drawcb(self) {
                if (self.data.isMenuFlag && self.data.enabled) {
                    drawAtlasImage(self.pos.c().sub(halfsize), new Vector(2, 2), tilesize, memoryimage);
                }
                else {
                    drawAtlasImage(self.pos.c().sub(halfsize), new Vector(0, 2), tilesize, memoryimage);
                }
                // fillRect(self.pos,tilesize,true)
            },
            data: flagobject
        }));
        res.push(last(entitys));
    }
    return res;
}
function switchLevel(index) {
    //reset mapdata
    entitys = [];
    tiledmap = levels[index];
    tiledmap.layers[0].data = tiledmap.layers[0].backup.slice();
    loadlevelcallbacks[index]();
}
function loadWallsIntoBits(wallstl, wallsbr, destination, wallgid, grassgid) {
    var res = [];
    wallstl.to(wallsbr).div(tilesize).add(new Vector(1, 1)).loop(v => {
        var absrel = v.c().mul(tilesize);
        var abspos = absrel.c().add(wallstl);
        var index = vector2index(abspos.c().div(tilesize), tiledmap.width);
        var gid = tiledmap.layers[0].data[index];
        if (gid != wallgid) {
            return;
        }
        var bitpos = destination.c().add(v.c().mul(tilesize));
        entitys.push(new Entity({
            pos: bitpos,
            rect: Rect.fromsize(bitpos, tilesize),
            type: 'bit',
            updatecb(self) {
                var index = vector2index(abspos.c().div(tilesize), tiledmap.width);
                tiledmap.layers[0].data[index] = self.data.get() == 1 ? wallgid : grassgid;
            },
            drawcb(self) {
                var bit = self.data;
                ctxt.textAlign = 'center';
                ctxt.textBaseline = 'middle';
                ctxt.font = '30px Arial';
                ctxt.fillStyle = bit.get() ? 'white' : 'black';
                fillRect(self.pos, tilesize);
                ctxt.fillStyle = bit.get() ? 'black' : 'white';
                ctxt.fillText(bit.get().toString(), self.pos.x + halfsize.x, self.pos.y + halfsize.y + 3);
            },
            data: new Bit({
                array: [1],
                index: 0,
            })
        }));
        res.push(last(entitys));
    });
    return res;
}
function findObjectsOfType(type) {
    var _a;
    var res = [];
    for (var layer of tiledmap.layers) {
        for (var object of (_a = layer.objects) !== null && _a !== void 0 ? _a : []) {
            if (object.class == type) {
                res.push(object);
            }
        }
    }
    return res;
}
function findObjectWithId(id) {
    var _a;
    for (var layer of tiledmap.layers) {
        for (var object of (_a = layer.objects) !== null && _a !== void 0 ? _a : []) {
            if (object.id == id) {
                return object;
            }
        }
    }
    return null;
}
function findObjectWithName(name) {
    var _a;
    for (var layer of tiledmap.layers) {
        for (var object of (_a = layer.objects) !== null && _a !== void 0 ? _a : []) {
            if (object.name == name) {
                return object;
            }
        }
    }
    return null;
}
//make 2 guns 1 for overworld, 1 for bitworld
//lets do enemys first
//only show 1 variable with 4 bits, speed
//makes it more obvious what is what
//in a second level also add health
function loadLevel2() {
    movePlayerToSpawn();
    loadTeleports();
    // initBits(findObjectWithName('gunbits').pos,normalgun.data)
    var dummy = new Enemy({});
    loadWallsIntoBits(findObjectWithName('mark1').pos, findObjectWithName('mark2').pos, findObjectWithName('ref1').pos, 92, 1);
    var enemys = loadEnemys();
    initBits(findObjectWithName('enemybits').pos, enemys[0].data.data, false, 8, 14);
    loadFlags();
    entitys.push(new Entity({
        updatecb(self) {
            player.data.gun.setProp('ammo', 6);
        },
    }));
}
function loadEnemys() {
    var res = [];
    var enemys = findObjectsOfType('enemy');
    for (let object of enemys) {
        entitys.push(new Entity({
            type: 'enemy',
            pos: object.pos.c(),
            rect: Rect.fromCenter(object.pos.c(), new Vector(32, 64)),
            updatecb(self) {
                self.data.attackcd.update(globaldt);
                if (player.data.inBitWorld == false) {
                    var oldpos = self.pos.c();
                    moveEntity(self, self.pos.to(player.pos).normalize().scale(self.data.getProp('speed') * 50 * globaldt));
                    self.data.changepos = oldpos.to(self.pos);
                }
                if (player.rect.collideBox(self.rect) && self.data.attackcd.tryfire()) {
                    player.data.health -= self.data.getProp('damage');
                    if (player.data.health <= 0) {
                        switchLevel(3);
                    }
                }
            },
            drawcb(self) {
                var playerdir = self.pos.to(player.pos);
                var flipx = playerdir.x < 0 ? true : false;
                if (self.data.changepos.length() > 0.05) {
                    drawAnimation(self.pos, skeletonWalkAnimation, time, flipx, true);
                }
                else {
                    drawAnimation(self.pos, skeletonIdleAnimation, time, flipx, true);
                }
            },
            data: new Enemy({
                damage: 0b0100,
                speed: 0b0110,
                health: 0b111111,
                changepos: new Vector(0, 0),
            })
        }));
        res.push(last(entitys));
    }
    return res;
}
//change ammo and firerate
function loadLevel3() {
    player.data.gun = new Gun({
        ammo: 0b00000100,
        firerate: 0b0001,
    });
    movePlayerToSpawn();
    loadTeleports();
    var enemys = loadEnemys();
    for (var enemy of enemys) {
        enemy.data.setProp('health', 5);
    }
    initBits(findObjectWithName('gunbits').pos, player.data.gun.data, false, 0, 8);
    loadWallsIntoBits(findObjectWithName('mark1').pos, findObjectWithName('mark2').pos, findObjectWithName('ref1').pos, 92, 1);
    loadFlags();
}
function loadMenulevel() {
    movePlayerToSpawn();
    loadTeleports();
    var enemys = loadEnemys();
    // initBits(findObjectWithName('gunbits').pos,normalgun.data)
    // initBits(findObjectWithName('enemybits').pos,enemys[0].data.data,false,8,12)
    // loadWallsIntoBits(findObjectWithName('mark1').pos,findObjectWithName('mark2').pos,findObjectWithName('ref1').pos,92,1)
    var flags = loadFlags();
    if (drawdebuggraphics == false) {
        var i = 0;
        for (var flag of flags) {
            flag.data.isMenuFlag = true;
            flag.data.enabled = levelunlocked[i];
            i++;
        }
    }
}
function loadFinishedLevel() {
    movePlayerToSpawn();
    loadTeleports();
    loadFlags();
}
/// <reference path="libs/vector/vector.ts" />
/// <reference path="libs/utils/rng.ts" />
/// <reference path="libs/utils/store.ts" />
/// <reference path="libs/utils/table.ts" />
/// <reference path="libs/utils/utils.ts" />
/// <reference path="libs/utils/stopwatch.ts" />
/// <reference path="libs/utils/ability.ts" />
/// <reference path="libs/utils/anim.ts" />
/// <reference path="libs/rect/rect.ts" />
/// <reference path="libs/event/eventqueue.ts" />
/// <reference path="libs/event/eventsystem.ts" />
/// <reference path="libs/utils/camera.ts" />
/// <reference path="libs/networking/entity.ts" />
/// <reference path="libs/networking/server.ts" />
/// <reference path="libs/utils/domutils.js" />
/// <reference path="src/utils.ts" />
/// <reference path="src/bit.ts" />
/// <reference path="src/enemy.ts" />
/// <reference path="src/cooldown.ts" />
/// <reference path="src/gun.ts" />
/// <reference path="src/entity.ts" />
/// <reference path="src/animation.ts" />
/// <reference path="src/player.ts" />
/// <reference path="src/tiled.js" />
/// <reference path="src/level1.ts" />
/// <reference path="src/level2.ts" />
/// <reference path="src/level3.ts" />
/// <reference path="src/menulevel.ts" />
/// <reference path="src/finishedlevel.ts" />
//todo
//last 4 bits on level3
//testupload to see how it looks on itch.io
//write description
//record video with playthrough
var drawdebuggraphics = location.hostname === "localhost";
var memoryimage = loadImage('res/memoryworld.png');
var TileMaps;
var levels = [TileMaps.level1, TileMaps.level2, TileMaps.level3, TileMaps.menulevel, TileMaps.finished];
var levelindex = 3;
var tiledmap = levels[levelindex];
var levelunlocked = [true, false, false];
for (var level of levels) {
    preprocessTiledMap(level);
}
var screensize = new Vector(document.documentElement.clientWidth, document.documentElement.clientHeight);
var crret = createCanvas(screensize.x, screensize.y);
var { canvas, ctxt } = crret;
console.log('here');
var tilesize = new Vector(tiledmap.tilewidth, tiledmap.tileheight);
var riflesound = new Howl({
    src: ['sounds/rifle.wav'],
    volume: 0.5,
});
var lasersound = new Howl({
    src: ['sounds/laser.wav'],
    volume: 0.5,
});
var shotgunsound = new Howl({
    src: ['sounds/shotgun.wav'],
    volume: 0.5,
});
var pistolsound = new Howl({
    src: ['sounds/pistol.wav'],
    volume: 0.5,
});
var fireballsound = new Howl({
    src: ['sounds/fireball.wav'],
    volume: 1,
});
var bitmusic = new Howl({
    src: ['sounds/bitmusic.wav'],
    volume: 1,
    loop: true,
});
var normalmusic = new Howl({
    src: ['sounds/normalmusic.mp3'],
    volume: 1,
    loop: true,
});
var teleportsound = new Howl({
    src: ['sounds/teleport.wav'],
    volume: 1,
});
var witchRunAnimation = new SpriteAnimation({
    imageatlas: loadImage('animations/B_witch_run.png'),
    startpos: new Vector(0, 0),
    direction: new Vector(0, 1),
    framecount: 8,
    duration: 1,
    spritesize: new Vector(32, 48)
});
var witchIdleAnimation = new SpriteAnimation({
    imageatlas: loadImage('animations/B_witch_idle.png'),
    startpos: new Vector(0, 0),
    direction: new Vector(0, 1),
    framecount: 6,
    duration: 1,
    spritesize: new Vector(32, 48)
});
var fireballAnimation = new SpriteAnimation({
    imageatlas: loadImage('animations/All_Fire_Bullet_Pixel_16x16.png'),
    startpos: new Vector(0, 14),
    direction: new Vector(1, 0),
    framecount: 5,
    duration: 0.4,
    spritesize: new Vector(16, 16)
});
var skeletonWalkAnimation = new SpriteAnimation({
    imageatlas: loadImage('animations/Skeleton enemy.png'),
    startpos: new Vector(0, 2),
    direction: new Vector(1, 0),
    framecount: 12,
    duration: 1,
    spritesize: new Vector(64, 64)
});
var skeletonIdleAnimation = new SpriteAnimation({
    imageatlas: loadImage('animations/Skeleton enemy.png'),
    startpos: new Vector(0, 3),
    direction: new Vector(1, 0),
    framecount: 4,
    duration: 1,
    spritesize: new Vector(64, 64)
});
var flipx = false;
var currentanimation = witchRunAnimation;
var halfsize = tilesize.c().scale(0.5);
var player = new Entity({
    pos: new Vector(0, 0),
    rect: Rect.fromsize(new Vector(0, 0), new Vector(26, 48)),
    data: new Player({
        speed: 200,
    })
});
var entitys = [];
var camera = new Camera(ctxt);
document.addEventListener('keydown', (e) => {
    if (e.key == 'f') {
    }
});
class Bullet {
    constructor() {
        this.isBitBullet = false;
    }
}
var mousebuttons = [];
var mousebuttonsPressed = [];
var mousepos = new Vector(0, 0);
document.addEventListener('mousemove', e => {
    mousepos = getMousePos(canvas, e);
});
document.addEventListener('mousedown', e => {
    mousebuttonsPressed[e.button] = true;
    mousebuttons[e.button] = true;
});
document.addEventListener('mouseup', e => {
    mousebuttons[e.button] = false;
});
var loadlevelcallbacks = [loadLevel1, loadLevel2, loadLevel3, loadMenulevel, loadFinishedLevel];
loadlevelcallbacks[levelindex]();
normalmusic.play();
var globaldt = 0;
var time = 0;
loop((dt) => {
    var _a, _b;
    dt = clamp(dt, 1 / 144, 1 / 30);
    globaldt = dt;
    time += dt;
    // ctxt.clearRect(0,0,screensize.x,screensize.y)
    ctxt.fillStyle = 'gray';
    ctxt.fillRect(0, 0, screensize.x, screensize.y);
    var dir = new Vector(0, 0);
    if (keys['w']) {
        dir.y--;
    }
    if (keys['s']) {
        dir.y++;
    }
    if (keys['a']) {
        dir.x--;
        flipx = true;
    }
    if (keys['d']) {
        dir.x++;
        flipx = false;
    }
    if (dir.length() > 0) {
        dir.normalize();
        currentanimation = witchRunAnimation;
    }
    else {
        currentanimation = witchIdleAnimation;
    }
    moveEntity(player, dir.scale(player.data.speed * dt));
    playercb(player);
    for (var entity of entitys) {
        if (entity.markedForDeletion) {
            continue;
        }
        (_a = entity.updatecb) === null || _a === void 0 ? void 0 : _a.call(entity, entity);
    }
    entitys = entitys.filter(e => e.markedForDeletion == false);
    camera.pos.overwrite(player.pos);
    // camera.scale = new Vector(1,1)
    camera.begin();
    renderTiled(tiledmap);
    for (var entity of entitys) {
        ctxt.globalAlpha = 1;
        if (entity.markedForDeletion) {
            continue;
        }
        (_b = entity.drawcb) === null || _b === void 0 ? void 0 : _b.call(entity, entity);
    }
    if (drawdebuggraphics) {
        ctxt.globalAlpha = 1;
        ctxt.strokeStyle = 'magenta';
        for (var entity of entitys) {
            if (entity.rect) {
                drawRectBorder(entity.rect);
            }
        }
    }
    ctxt.globalAlpha = 1;
    ctxt.fillStyle = 'red';
    if (player.data.inBitWorld) {
        ctxt.strokeStyle = 'white';
        drawRectBorder(player.rect);
    }
    else {
        drawAnimation(player.pos, currentanimation, time, flipx, true);
    }
    // fillRect(player.pos,player.rect.size(),true)
    camera.end();
    mousebuttonsPressed.fill(false);
});
function drawRectBorder(rect) {
    ctxt.beginPath();
    ctxt.moveTo(rect.min.x + 0.5, rect.min.y + 0.5);
    ctxt.lineTo(rect.max.x + 0.5, rect.min.y + 0.5);
    ctxt.lineTo(rect.max.x + 0.5, rect.max.y + 0.5);
    ctxt.lineTo(rect.min.x + 0.5, rect.max.y + 0.5);
    ctxt.closePath();
    ctxt.stroke();
}
function moveEntity(entity, vel) {
    var oldpos = entity.pos.c();
    if (vel.x == 0 && vel.y == 0) {
        return;
    }
    entity.pos.x += vel.x;
    entity.rect.moveToCentered(entity.pos);
    if (collissionCheckWorld(entity.rect)) {
        entity.pos.x = oldpos.x;
        entity.rect.moveToCentered(entity.pos);
    }
    entity.pos.y += vel.y;
    entity.rect.moveToCentered(entity.pos);
    if (collissionCheckWorld(entity.rect)) {
        entity.pos.y = oldpos.y;
        entity.rect.moveToCentered(entity.pos);
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFja2FnZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImxpYnMvdmVjdG9yL3ZlY3Rvci50cyIsImxpYnMvdXRpbHMvcm5nLnRzIiwibGlicy91dGlscy9zdG9yZS50cyIsImxpYnMvdXRpbHMvdGFibGUudHMiLCJsaWJzL3V0aWxzL3V0aWxzLnRzIiwibGlicy91dGlscy9zdG9wd2F0Y2gudHMiLCJsaWJzL3V0aWxzL2FiaWxpdHkudHMiLCJsaWJzL3V0aWxzL2FuaW0udHMiLCJsaWJzL3JlY3QvcmVjdC50cyIsImxpYnMvZXZlbnQvZXZlbnRxdWV1ZS50cyIsImxpYnMvZXZlbnQvZXZlbnRzeXN0ZW0udHMiLCJsaWJzL3V0aWxzL2NhbWVyYS50cyIsImxpYnMvbmV0d29ya2luZy9lbnRpdHkudHMiLCJsaWJzL25ldHdvcmtpbmcvc2VydmVyLnRzIiwibGlicy91dGlscy9kb211dGlscy5qcyIsInNyYy91dGlscy50cyIsInNyYy9iaXQudHMiLCJzcmMvZW5lbXkudHMiLCJzcmMvY29vbGRvd24udHMiLCJzcmMvZ3VuLnRzIiwic3JjL2VudGl0eS50cyIsInNyYy9hbmltYXRpb24udHMiLCJzcmMvcGxheWVyLnRzIiwic3JjL3RpbGVkLmpzIiwic3JjL2xldmVsMS50cyIsInNyYy9sZXZlbDIudHMiLCJzcmMvbGV2ZWwzLnRzIiwic3JjL21lbnVsZXZlbC50cyIsInNyYy9maW5pc2hlZGxldmVsLnRzIiwibWFpbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxNQUFNLE1BQU07SUFHUixZQUFZLEdBQUcsSUFBYTtRQUN4QixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQTtJQUNwQixDQUFDO0lBRUQsR0FBRyxDQUFDLFFBQXdDO1FBQ3hDLEtBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBQztZQUNyQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksRUFBQyxDQUFDLENBQUMsQ0FBQTtTQUN4QjtRQUNELE9BQU8sSUFBSSxDQUFBO0lBQ2YsQ0FBQztJQUVELEdBQUcsQ0FBQyxDQUFRO1FBQ1IsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTtJQUNuRCxDQUFDO0lBRUQsR0FBRyxDQUFDLENBQVE7UUFDUixPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFBO0lBQ25ELENBQUM7SUFFRCxLQUFLO1FBQ0QsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTtJQUMzRCxDQUFDO0lBRUQsSUFBSTtRQUNBLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7SUFDMUQsQ0FBQztJQUVELEtBQUs7UUFDRCxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFBO0lBQzNELENBQUM7SUFFRCxHQUFHLENBQUMsQ0FBUTtRQUNSLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7SUFDbkQsQ0FBQztJQUVELEdBQUcsQ0FBQyxDQUFRO1FBQ1IsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTtJQUNuRCxDQUFDO0lBRUQsS0FBSyxDQUFDLENBQVE7UUFDVixPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUE7SUFDM0MsQ0FBQztJQUVELE1BQU07UUFDRixJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUE7UUFDWCxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsR0FBRyxJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTtRQUMzQyxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFDLEdBQUcsQ0FBQyxDQUFBO0lBQzVCLENBQUM7SUFFRCxTQUFTO1FBQ0wsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQTtJQUN4QyxDQUFDO0lBRUQsRUFBRSxDQUFDLENBQVE7UUFDUCxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUE7SUFDMUIsQ0FBQztJQUVELElBQUksQ0FBQyxDQUFRLEVBQUMsTUFBYTtRQUN2QixPQUFPLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQTtJQUNqRCxDQUFDO0lBRUQsQ0FBQztRQUNHLE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUE7SUFDOUMsQ0FBQztJQUVELFNBQVMsQ0FBQyxDQUFRO1FBQ2QsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTtJQUNsRCxDQUFDO0lBRUQsR0FBRyxDQUFDLENBQVE7UUFDUixJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUE7UUFDWCxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsR0FBRyxJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7UUFDOUMsT0FBTyxHQUFHLENBQUE7SUFDZCxDQUFDO0lBRUQsT0FBTyxDQUFDLENBQVE7UUFDWixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFBO0lBQ2hFLENBQUM7SUFFRCxRQUFRLENBQUMsS0FBSztRQUNWLElBQUksT0FBTyxHQUFHLEtBQUssR0FBRyxJQUFJLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQTtRQUNqQyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzdCLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDN0IsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUM7UUFDdEMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUM7UUFDdEMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDWCxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNYLE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFFRCxRQUFRLENBQUMsSUFBVyxFQUFDLE9BQWM7UUFDL0IsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQTtRQUM1QixJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFBO1FBQzVCLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUE7UUFDOUIsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFBO1FBQ3JDLEdBQUcsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQTtRQUNwRCxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFBO1FBQ25CLE9BQU8sSUFBSSxDQUFBO0lBQ2YsQ0FBQztJQUVELFdBQVcsQ0FBQyxDQUFRO1FBQ2hCLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUE7SUFDaEUsQ0FBQztJQUVELFdBQVcsQ0FBQyxDQUFDO1FBQ1QsOEZBQThGO1FBQzlGLElBQUksT0FBTyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxTQUFTLEVBQUUsQ0FBQTtRQUMvQixPQUFPLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFBO0lBQzNDLENBQUM7SUFFRCxNQUFNLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBQyxLQUFLO1FBQzFCLElBQUksTUFBTSxHQUFHLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTtRQUNoQyxJQUFJLE1BQU0sR0FBRyxNQUFNLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFBO1FBQzFDLElBQUksVUFBVSxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDbkMsSUFBSSxJQUFJLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDM0MsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQUVELEtBQUssQ0FBQyxDQUFDO1FBQ0gsOEZBQThGO1FBQzlGLE9BQU8sSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQTtJQUN0QyxDQUFDO0lBQ0QsNENBQTRDO0lBQzVDLDZGQUE2RjtJQUM3RixTQUFTO0lBRVQsSUFBSSxDQUFDLENBQUM7UUFDRixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFBO0lBQzVCLENBQUM7SUFFRCxJQUFJLENBQUMsUUFBa0M7UUFDbkMsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFBO1FBQ3RCLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFBO1FBRXBCLE9BQU0sT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBQztZQUM5QixRQUFRLENBQUMsT0FBTyxDQUFDLENBQUE7WUFDakIsSUFBRyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFDO2dCQUNsQixNQUFNO2FBQ1Q7U0FDSjtJQUNMLENBQUM7SUFFRCxPQUFPLENBQUMsQ0FBUTtRQUNaLEtBQUssSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDckQsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQzdCLFNBQVM7YUFDVDtpQkFDSSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDdkIsT0FBTyxDQUFDLENBQUM7YUFDckI7aUJBQ0k7Z0JBQ0osT0FBTyxDQUFDLENBQUM7YUFDVDtTQUNEO1FBQ0QsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUNSLENBQUM7SUFFRCxJQUFJLENBQUMsVUFBa0I7UUFDbkIsS0FBSSxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFDO1lBQzlDLElBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUM7Z0JBQzFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztnQkFDZixPQUFPLEtBQUssQ0FBQzthQUNiO2lCQUFJO2dCQUNKLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQ2pCO1NBQ0Q7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNWLENBQUM7SUFFRCxPQUFPLENBQUMsQ0FBUTtRQUNiLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTtJQUM3QyxDQUFDO0lBRUQsR0FBRyxDQUFDLENBQVE7UUFDUixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUE7SUFDdkIsQ0FBQztJQUVELEdBQUcsQ0FBQyxDQUFRLEVBQUMsR0FBVTtRQUNuQixJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQTtJQUN0QixDQUFDO0lBRUQsSUFBSSxDQUFDO1FBQ0QsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFBO0lBQ3ZCLENBQUM7SUFFRCxJQUFJLENBQUM7UUFDRCxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUE7SUFDdkIsQ0FBQztJQUVELElBQUksQ0FBQztRQUNELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQTtJQUN2QixDQUFDO0lBRUQsSUFBSSxDQUFDLENBQUMsR0FBRztRQUNMLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFBO0lBQ3RCLENBQUM7SUFFRCxJQUFJLENBQUMsQ0FBQyxHQUFHO1FBQ0wsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUE7SUFDdEIsQ0FBQztJQUVELElBQUksQ0FBQyxDQUFDLEdBQUc7UUFDTCxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQTtJQUN0QixDQUFDO0lBRUQsSUFBSSxDQUFDLElBQTZCO1FBQzlCLElBQUksS0FBSyxHQUFHLEVBQUUsQ0FBQTtRQUNkLElBQUksU0FBUyxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUE7UUFDekIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLFNBQVMsRUFBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLFNBQVMsRUFBQyxLQUFLLEVBQUMsS0FBSyxDQUFDLENBQUE7SUFDcEUsQ0FBQztJQUVELEtBQUssQ0FBQyxDQUFRO1FBQ1YsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQTtRQUNuQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFBO1FBQ25DLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUE7UUFDbkMsT0FBTyxJQUFJLE1BQU0sQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFBO0lBQzVCLENBQUM7SUFFRCxNQUFNLENBQUMsU0FBUyxDQUFDLElBQWE7UUFDMUIsSUFBSSxDQUFDLEdBQUcsSUFBSSxNQUFNLEVBQUUsQ0FBQTtRQUNwQixDQUFDLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQTtRQUNiLE9BQU8sQ0FBQyxDQUFBO0lBQ1osQ0FBQztJQUVELE1BQU0sQ0FBQyxRQUE2QjtRQUNoQyxJQUFJLE9BQU8sR0FBRyxJQUFJLE1BQU0sQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUE7UUFDN0IsS0FBSSxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUMsRUFBRSxFQUFDO1lBQy9DLEtBQUksT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDLEVBQUUsRUFBQztnQkFDL0MsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFBO2FBQ3BCO1NBQ0o7SUFDTCxDQUFDO0lBRUQsTUFBTSxDQUFDLFFBQTZCO1FBQ2hDLElBQUksT0FBTyxHQUFHLElBQUksTUFBTSxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUE7UUFDL0IsS0FBSSxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUMsRUFBRSxFQUFDO1lBQy9DLEtBQUksT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDLEVBQUUsRUFBQztnQkFDL0MsS0FBSSxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUMsRUFBRSxFQUFDO29CQUMvQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUE7aUJBQ3BCO2FBQ0o7U0FDSjtJQUNMLENBQUM7Q0FDSjtBQUdELHlDQUF5QztBQUN6QyxRQUFRO0FBQ1IseUNBQXlDO0FBQ3pDLDRDQUE0QztBQUM1Qyw4QkFBOEI7QUFDOUIsZ0JBQWdCO0FBRWhCLDBDQUEwQztBQUMxQyxxRUFBcUU7QUFDckUsZ0JBQWdCO0FBRWhCLDBDQUEwQztBQUMxQyxnRkFBZ0Y7QUFDaEYsZ0JBQWdCO0FBRWhCLGFBQWE7QUFFYixrQ0FBa0M7QUFDbEMsMkJBQTJCO0FBQzNCLGFBQWE7QUFDYixRQUFRO0FBQ1IsSUFBSTtBQzlRSixNQUFNLEdBQUc7SUFLTCxZQUFtQixJQUFXO1FBQVgsU0FBSSxHQUFKLElBQUksQ0FBTztRQUp2QixRQUFHLEdBQVUsVUFBVSxDQUFBO1FBQ3ZCLGVBQVUsR0FBVSxPQUFPLENBQUE7UUFDM0IsY0FBUyxHQUFVLFVBQVUsQ0FBQTtJQUlwQyxDQUFDO0lBRUQsSUFBSTtRQUNBLElBQUksQ0FBQyxJQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUE7UUFDckUsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFBO0lBQ3BCLENBQUM7SUFFRCxJQUFJO1FBQ0EsT0FBTyxJQUFJLENBQUMsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQTtJQUNqQyxDQUFDO0lBRUQsS0FBSyxDQUFDLEdBQVUsRUFBQyxHQUFVO1FBQ3ZCLE9BQU8sSUFBSSxDQUFDLEdBQUcsRUFBQyxHQUFHLEVBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUE7SUFDcEMsQ0FBQztJQUVELFVBQVUsQ0FBQyxHQUFVLEVBQUMsR0FBVTtRQUM1QixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQTtJQUMxQyxDQUFDO0lBRUQsTUFBTSxDQUFJLEdBQU87UUFDYixPQUFPLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsRUFBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQTtJQUM3QyxDQUFDO0lBRUQsT0FBTyxDQUFJLEdBQU87UUFDZCxLQUFJLElBQUksR0FBRyxHQUFHLEdBQUcsQ0FBQyxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsRUFBRSxHQUFHLEVBQUUsRUFBRTtZQUN4QyxJQUFJLENBQUMsR0FBRyxFQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxFQUFDLEdBQUcsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFBO1NBQ3RDO1FBQ0QsT0FBTyxHQUFHLENBQUM7SUFDZixDQUFDO0NBQ0o7QUNwQ0QsTUFBTSxLQUFLO0lBQVg7UUFFSSxRQUFHLEdBQUcsSUFBSSxHQUFHLEVBQVksQ0FBQTtRQUN6QixZQUFPLEdBQUcsQ0FBQyxDQUFBO0lBb0JmLENBQUM7SUFsQkcsR0FBRyxDQUFDLEVBQVM7UUFDVCxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFBO0lBQzNCLENBQUM7SUFFRCxHQUFHLENBQUMsSUFBTTtRQUNMLElBQVksQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFBO1FBQ2pDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFFLElBQVksQ0FBQyxFQUFFLEVBQUMsSUFBSSxDQUFDLENBQUE7SUFDdkMsQ0FBQztJQUVELElBQUk7UUFDQSxPQUFPLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFBO0lBQ3hDLENBQUM7SUFFRCxNQUFNLENBQUMsRUFBRTtRQUNMLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFBO1FBQzFCLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFBO1FBQ25CLE9BQU8sR0FBRyxDQUFBO0lBQ2QsQ0FBQztDQUNKO0FFdEJELElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFBO0FBQ3JCLFNBQVMsR0FBRyxDQUFDLEdBQVUsRUFBQyxLQUFZLEVBQUMsS0FBWSxFQUFDLEdBQVUsRUFBQyxHQUFVO0lBQ25FLE9BQU8sSUFBSSxDQUFDLEdBQUcsRUFBQyxHQUFHLEVBQUMsV0FBVyxDQUFDLEdBQUcsRUFBQyxLQUFLLEVBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQTtBQUNyRCxDQUFDO0FBRUQsU0FBUyxXQUFXLENBQUMsR0FBVSxFQUFDLENBQVEsRUFBQyxDQUFRO0lBQzdDLE9BQU8sRUFBRSxDQUFDLENBQUMsRUFBQyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFBO0FBQzlCLENBQUM7QUFFRCxTQUFTLE9BQU8sQ0FBQyxHQUFXLEVBQUUsR0FBVyxFQUFFLEtBQWE7SUFDcEQsSUFBRyxHQUFHLEdBQUcsR0FBRyxFQUFDO1FBQ1QsSUFBSSxJQUFJLEdBQUcsR0FBRyxDQUFDO1FBQ2YsR0FBRyxHQUFHLEdBQUcsQ0FBQztRQUNWLEdBQUcsR0FBRyxJQUFJLENBQUM7S0FDZDtJQUNELE9BQU8sS0FBSyxJQUFJLEdBQUcsSUFBSSxLQUFLLElBQUksR0FBRyxDQUFDO0FBQ3hDLENBQUM7QUFFRCxTQUFTLEdBQUcsQ0FBQyxDQUFTLEVBQUUsQ0FBUztJQUM3QixJQUFHLENBQUMsR0FBRyxDQUFDO1FBQUMsT0FBTyxDQUFDLENBQUM7SUFDbEIsT0FBTyxDQUFDLENBQUM7QUFDYixDQUFDO0FBRUQsU0FBUyxHQUFHLENBQUMsQ0FBUyxFQUFFLENBQVM7SUFDN0IsSUFBRyxDQUFDLEdBQUcsQ0FBQztRQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ2xCLE9BQU8sQ0FBQyxDQUFDO0FBQ2IsQ0FBQztBQUVELFNBQVMsS0FBSyxDQUFDLEdBQVcsRUFBRSxHQUFXLEVBQUUsR0FBVztJQUNoRCxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUE7QUFDNUMsQ0FBQztBQUVELFNBQVMsWUFBWSxDQUFDLEVBQVUsRUFBRSxFQUFVLEVBQUUsRUFBVSxFQUFFLEVBQVU7SUFDaEUsT0FBTyxHQUFHLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLElBQUksR0FBRyxDQUFDLEVBQUUsRUFBQyxFQUFFLENBQUMsSUFBSSxHQUFHLENBQUMsRUFBRSxFQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ2xFLENBQUM7QUFFRCxTQUFTLGdCQUFnQixDQUFDLFdBQTZCO0lBQ25ELElBQUksUUFBUSxHQUFHLElBQUksTUFBTSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQTtJQUM5QixRQUFRLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxFQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUU7UUFDeEMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsV0FBVyxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7SUFDbEQsQ0FBQyxDQUFDLENBQUE7SUFDRixPQUFPLFFBQVEsQ0FBQTtBQUNuQixDQUFDO0FBRUQsU0FBUyxXQUFXLENBQUMsTUFBd0IsRUFBRSxHQUFjO0lBQ3pELElBQUksSUFBSSxHQUFHLE1BQU0sQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO0lBQzFDLE9BQU8sSUFBSSxNQUFNLENBQUMsR0FBRyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFBO0FBQ3RFLENBQUM7QUFFRCxTQUFTLFlBQVksQ0FBQyxDQUFTLEVBQUUsQ0FBUztJQUN0QyxJQUFJLE1BQU0sR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFBO0lBQzdDLE1BQU0sQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO0lBQ2pCLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0lBQ2xCLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFBO0lBQ2pDLElBQUksSUFBSSxHQUFHLE1BQU0sQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUE7SUFDbEMsT0FBTyxFQUFDLElBQUksRUFBQyxJQUFJLEVBQUMsTUFBTSxFQUFDLE1BQU0sRUFBQyxDQUFDO0FBQ3JDLENBQUM7QUFFRCxTQUFTLE1BQU0sQ0FBQyxHQUFXLEVBQUUsR0FBVztJQUNwQyxPQUFPLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQUE7QUFDNUMsQ0FBQztBQUdELElBQUksVUFBVSxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztBQUM1QixTQUFTLElBQUksQ0FBQyxRQUFRO0lBQ2xCLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQTtJQUNwQixRQUFRLENBQUMsQ0FBQyxHQUFHLEdBQUcsVUFBVSxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUE7SUFDbkMsVUFBVSxHQUFHLEdBQUcsQ0FBQTtJQUNoQixxQkFBcUIsQ0FBQyxHQUFHLEVBQUU7UUFDdkIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFBO0lBQ2xCLENBQUMsQ0FBQyxDQUFBO0FBQ04sQ0FBQztBQUVELFNBQVMsR0FBRyxDQUFDLE1BQWMsRUFBRSxPQUFlO0lBQ3hDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sR0FBQyxPQUFPLENBQUMsR0FBQyxPQUFPLENBQUMsR0FBQyxPQUFPLENBQUM7QUFDOUMsQ0FBQztBQUVELElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQTtBQUViLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRTtJQUN2QyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQTtBQUN0QixDQUFDLENBQUMsQ0FBQTtBQUVGLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRTtJQUNyQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUssQ0FBQTtBQUN2QixDQUFDLENBQUMsQ0FBQTtBQUVGLFNBQVMsWUFBWTtJQUNqQixJQUFJLEdBQUcsR0FBRyxJQUFJLE1BQU0sQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUE7SUFDekIsSUFBRyxJQUFJLENBQUMsR0FBRyxDQUFDO1FBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFBLENBQUEsTUFBTTtJQUMxQixJQUFHLElBQUksQ0FBQyxHQUFHLENBQUM7UUFBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUEsQ0FBQSxJQUFJO0lBQ3hCLElBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQztRQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQSxDQUFBLE9BQU87SUFDM0IsSUFBRyxJQUFJLENBQUMsR0FBRyxDQUFDO1FBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFBLENBQUEsTUFBTTtJQUMxQixPQUFPLEdBQUcsQ0FBQztBQUNmLENBQUM7QUFFRCxTQUFTLG9CQUFvQjtJQUN6QixJQUFJLEtBQUssR0FBRyxZQUFZLEVBQUUsQ0FBQTtJQUMxQixLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFBO0lBQ2IsT0FBTyxLQUFLLENBQUE7QUFDaEIsQ0FBQztBQUVELFNBQVMsYUFBYSxDQUFDLE9BQWdCO0lBQ25DLElBQUksUUFBUSxHQUFHLEVBQUUsQ0FBQTtJQUNqQixLQUFJLElBQUksTUFBTSxJQUFJLE9BQU8sRUFBQztRQUN0QixJQUFJLE9BQU8sR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDO2FBQzFCLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQzthQUN6QixJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQTtRQUNuQixRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFBO0tBQ3pCO0lBQ0QsT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFBO0FBQ2hDLENBQUM7QUFFRCxTQUFTLFVBQVUsQ0FBQyxJQUFhO0lBQzdCLElBQUksUUFBUSxHQUErQixFQUFFLENBQUE7SUFFN0MsS0FBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLEVBQUM7UUFDaEIsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLE9BQU8sQ0FBQyxDQUFDLEdBQUcsRUFBQyxHQUFHLEVBQUUsRUFBRTtZQUNsQyxJQUFJLEtBQUssR0FBRyxJQUFJLEtBQUssRUFBRSxDQUFBO1lBQ3ZCLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEVBQUU7Z0JBQ2YsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFBO1lBQ2QsQ0FBQyxDQUFBO1lBQ0QsS0FBSyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUE7UUFDbkIsQ0FBQyxDQUFDLENBQUMsQ0FBQTtLQUNOO0lBRUQsT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFBO0FBQ2hDLENBQUM7QUFFRCxTQUFTLGFBQWEsQ0FBSSxJQUFRLEVBQUUsU0FBeUI7SUFDekQsSUFBSSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtRQUNqQixPQUFPLENBQUMsQ0FBQyxDQUFDO0tBQ2I7SUFDRCxJQUFJLFNBQVMsR0FBRyxDQUFDLENBQUM7SUFDbEIsSUFBSSxTQUFTLEdBQUcsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFBO0lBQ2xDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1FBQ2xDLElBQUksS0FBSyxHQUFHLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTtRQUM5QixJQUFJLEtBQUssR0FBRyxTQUFTLEVBQUU7WUFDbkIsU0FBUyxHQUFHLEtBQUssQ0FBQTtZQUNqQixTQUFTLEdBQUcsQ0FBQyxDQUFBO1NBQ2hCO0tBQ0o7SUFDRCxPQUFPLFNBQVMsQ0FBQTtBQUNwQixDQUFDO0FBRUQsU0FBUyxJQUFJLENBQUMsQ0FBUSxFQUFDLENBQVEsRUFBQyxDQUFRO0lBQ3BDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFBO0FBQzFCLENBQUM7QUFFRCxTQUFTLEVBQUUsQ0FBQyxDQUFRLEVBQUMsQ0FBUTtJQUN6QixPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDakIsQ0FBQztBQUVELFNBQVMsSUFBSSxDQUFJLEdBQU8sRUFBQyxJQUFXLENBQUMsRUFBQyxJQUFXLENBQUM7SUFDOUMsSUFBSSxJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ2xCLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDaEIsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQztBQUNsQixDQUFDO0FBRUQsU0FBUyxLQUFLLENBQUksR0FBTztJQUNyQixPQUFPLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQTtBQUNqQixDQUFDO0FBRUQsU0FBUyxJQUFJLENBQUksR0FBTztJQUNwQixPQUFPLEdBQUcsQ0FBQyxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFBO0FBQzlCLENBQUM7QUFFRCxTQUFTLGFBQWEsQ0FBSSxJQUFXLEVBQUMsTUFBd0I7SUFDMUQsSUFBSSxNQUFNLEdBQUcsSUFBSSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFBO0lBQzlCLEtBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBRSxFQUFDO1FBQzFCLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUE7S0FDaEM7SUFDRCxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFO1FBQ1osTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFBO0lBQ2hDLENBQUMsQ0FBQyxDQUFBO0lBQ0YsT0FBTyxNQUFNLENBQUE7QUFDakIsQ0FBQztBQUVELFNBQVMsY0FBYyxDQUFDLEdBQVc7SUFDL0IsT0FBTyxJQUFJLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQTtBQUMvQyxDQUFDO0FBRUQsU0FBUyxPQUFPLENBQUksR0FBUyxFQUFDLENBQVE7SUFDbEMsT0FBTyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTtBQUN4QixDQUFDO0FBRUQsU0FBUyxXQUFXLENBQUksR0FBUztJQUM3QixPQUFPLGFBQWEsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUE7QUFDckUsQ0FBQztBQUVELFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBQyxRQUFRO0lBQzFCLElBQUksR0FBRyxHQUFHLEVBQUUsSUFBSSxRQUFRLENBQUE7SUFDeEIsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBSSxHQUFHLENBQUMsR0FBRyxHQUFHLENBQUE7QUFDMUMsQ0FBQztBQUVELElBQUksR0FBRyxHQUFHLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFBO0FBQ3BCLFNBQVMsT0FBTyxDQUFJLEtBQVM7SUFDekIsSUFBSSxZQUFZLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxjQUFjLEVBQUUsV0FBVyxDQUFDO0lBQzdELE9BQU8sQ0FBQyxLQUFLLFlBQVksRUFBRTtRQUN2QixXQUFXLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLEdBQUcsWUFBWSxDQUFDLENBQUM7UUFDcEQsWUFBWSxJQUFJLENBQUMsQ0FBQztRQUVsQixjQUFjLEdBQUcsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQ3JDLEtBQUssQ0FBQyxZQUFZLENBQUMsR0FBRyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDekMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxHQUFHLGNBQWMsQ0FBQztLQUN2QztJQUVELE9BQU8sS0FBSyxDQUFDO0FBQ2pCLENBQUM7QUFFRCxTQUFTLE1BQU0sQ0FBQyxHQUFHLEVBQUUsS0FBSztJQUN0QixJQUFJLEtBQUssR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQy9CLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFO1FBQ2QsR0FBRyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7S0FDdEI7SUFDRCxPQUFPLEdBQUcsQ0FBQztBQUNiLENBQUM7QUN6TkgsTUFBTSxTQUFTO0lBQWY7UUFFSSxtQkFBYyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQTtRQUMzQixtQkFBYyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQTtRQUMzQixjQUFTLEdBQUcsQ0FBQyxDQUFBO1FBQ2IsV0FBTSxHQUFHLElBQUksQ0FBQTtJQXNDakIsQ0FBQztJQXBDRyxHQUFHO1FBQ0MsSUFBSSxtQkFBbUIsR0FBRyxDQUFDLENBQUE7UUFDM0IsSUFBRyxJQUFJLENBQUMsTUFBTSxFQUFDO1lBQ1gsbUJBQW1CLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUE7U0FDM0Q7UUFDRCxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsR0FBRyxtQkFBbUIsQ0FBQyxDQUFBO0lBQ3ZGLENBQUM7SUFJRCxLQUFLO1FBQ0QsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUE7UUFDbkIsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUE7UUFDaEMsSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUE7SUFDdEIsQ0FBQztJQUVELFFBQVE7UUFDSixJQUFHLElBQUksQ0FBQyxNQUFNLEVBQUM7WUFDWCxJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQTtZQUNuQixJQUFJLENBQUMsU0FBUyxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFBO1NBQ3hEO0lBQ0wsQ0FBQztJQUVELEtBQUs7UUFDRCxJQUFHLElBQUksQ0FBQyxNQUFNLElBQUksS0FBSyxFQUFDO1lBQ3BCLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFBO1lBQ2xCLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFBO1NBQ25DO0lBQ0wsQ0FBQztJQUVELEtBQUs7UUFDRCxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQTtRQUNsQixJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQTtRQUNoQyxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQTtRQUNoQyxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQTtJQUN0QixDQUFDO0NBQ0o7QUMxQ0QsTUFBTSxJQUFJO0lBRU4sWUFBbUIsT0FBYyxFQUFRLEVBQWdCO1FBQXRDLFlBQU8sR0FBUCxPQUFPLENBQU87UUFBUSxPQUFFLEdBQUYsRUFBRSxDQUFjO0lBRXpELENBQUM7Q0FDSjtBQUVELE1BQU0sT0FBTztJQTBCVCxZQUFtQixFQUFhO1FBQWIsT0FBRSxHQUFGLEVBQUUsQ0FBVztRQXpCaEMsa0JBQWtCO1FBQ2xCLHFCQUFxQjtRQUNyQixpQ0FBaUM7UUFDakMseUJBQXlCO1FBQ3pCLGdDQUFnQztRQUVoQyxhQUFRLEdBQVUsSUFBSSxDQUFBO1FBQ3RCLGFBQVEsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUE7UUFDckIsVUFBSyxHQUFVO1lBQ1gsSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1NBTy9FLENBQUE7UUFDRCxjQUFTLEdBQWEsSUFBSSxTQUFTLEVBQUUsQ0FBQTtRQUNyQyxnQkFBVyxHQUFVLENBQUMsQ0FBQTtRQUN0QixtQkFBYyxHQUFHLElBQUksV0FBVyxFQUFFLENBQUE7UUFDbEMsVUFBSyxHQUFXLENBQUMsQ0FBQTtRQUNqQixXQUFNLEdBQVksS0FBSyxDQUFBO0lBTXZCLENBQUM7SUFFRCwrREFBK0Q7SUFDL0QsOEJBQThCO1FBQzFCLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRSxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQTtJQUN4RCxDQUFDO0lBRUQsV0FBVztRQUNQLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQTtJQUN4QyxDQUFDO0lBRUQsWUFBWTtRQUNSLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQTtJQUNiLENBQUM7SUFFRCxJQUFJO1FBQ0EsSUFBRyxJQUFJLENBQUMsTUFBTSxJQUFJLEtBQUssRUFBQztZQUNwQixJQUFJLENBQUMsU0FBUyxFQUFFLENBQUE7U0FDbkI7YUFBSTtZQUNELElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQTtTQUNsQjtJQUNMLENBQUM7SUFFRCxXQUFXO1FBQ1AsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUE7SUFDdkIsQ0FBQztJQUVELE9BQU87UUFDSCxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUE7UUFDaEIsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFBO0lBQ3RCLENBQUM7SUFFTyxTQUFTO1FBQ2IsSUFBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFDO1lBQzVCLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFBO1lBQ2xCLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFBO1lBQ3BCLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUE7WUFDdEIsSUFBSSxDQUFDLFdBQVcsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFBO1lBQ2pDLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFBO1lBQ2QsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUE7WUFDMUIsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFBO1NBQ1o7SUFDTCxDQUFDO0lBRU8sUUFBUTtRQUNaLElBQUksQ0FBQyxXQUFXLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQTtRQUN4QyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxDQUFBO1FBQ3RCLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQTtRQUN4RCxJQUFJLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQTtRQUM5QyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQTtRQUMxQixJQUFHLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxFQUFDO1lBQ2QsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFBO1NBQ1o7SUFDTCxDQUFDO0NBQ0o7QUMxRkQsSUFBSyxRQUFxQztBQUExQyxXQUFLLFFBQVE7SUFBQyx1Q0FBSSxDQUFBO0lBQUMsMkNBQU0sQ0FBQTtJQUFDLCtDQUFRLENBQUE7SUFBQywyQ0FBTSxDQUFBO0FBQUEsQ0FBQyxFQUFyQyxRQUFRLEtBQVIsUUFBUSxRQUE2QjtBQUUxQyxNQUFNLElBQUk7SUFRTjtRQVBBLGFBQVEsR0FBWSxRQUFRLENBQUMsSUFBSSxDQUFBO1FBQ2pDLFlBQU8sR0FBVyxLQUFLLENBQUE7UUFDdkIsYUFBUSxHQUFVLElBQUksQ0FBQTtRQUN0QixjQUFTLEdBQWEsSUFBSSxTQUFTLEVBQUUsQ0FBQTtRQUNyQyxVQUFLLEdBQVUsQ0FBQyxDQUFBO1FBQ2hCLFFBQUcsR0FBVSxDQUFDLENBQUE7SUFJZCxDQUFDO0lBRUQsR0FBRztRQUNDLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQTtRQUVqRCxRQUFRLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDbkIsS0FBSyxRQUFRLENBQUMsSUFBSTtnQkFDZCxPQUFPLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBQyxJQUFJLENBQUMsR0FBRyxFQUFDLE1BQU0sQ0FBQyxFQUFDLElBQUksQ0FBQyxLQUFLLEVBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFBO1lBQ3RFLEtBQUssUUFBUSxDQUFDLE1BQU07Z0JBQ2hCLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUMsSUFBSSxDQUFDLEdBQUcsRUFBQyxHQUFHLENBQUMsTUFBTSxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7WUFDbEQsS0FBSyxRQUFRLENBQUMsUUFBUTtnQkFFbEIsSUFBSSxhQUFhLEdBQUcsR0FBRyxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQTtnQkFDbEMsSUFBRyxhQUFhLElBQUksQ0FBQyxFQUFDO29CQUNsQixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFDLElBQUksQ0FBQyxHQUFHLEVBQUMsYUFBYSxDQUFDLENBQUE7aUJBQ2pEO3FCQUFJO29CQUNELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUMsSUFBSSxDQUFDLEtBQUssRUFBQyxhQUFhLEdBQUcsQ0FBQyxDQUFDLENBQUE7aUJBQ3JEO1lBRUwsS0FBSyxRQUFRLENBQUMsTUFBTTtnQkFDaEIsSUFBSSxZQUFZLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFBO2dCQUMxQyxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsWUFBWSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFDLElBQUksQ0FBQyxHQUFHLEVBQUMsR0FBRyxDQUFDLE1BQU0sRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFBO1NBQ3pGO0lBQ0wsQ0FBQztDQUNKO0FDbkNELE1BQU0sSUFBSTtJQUVOLFlBQW1CLEdBQVUsRUFBUyxHQUFVO1FBQTdCLFFBQUcsR0FBSCxHQUFHLENBQU87UUFBUyxRQUFHLEdBQUgsR0FBRyxDQUFPO0lBQ2hELENBQUM7SUFFRCxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQVUsRUFBQyxJQUFXO1FBQ2xDLE9BQU8sSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxFQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQTtJQUM5QyxDQUFDO0lBRUQsTUFBTSxDQUFDLFVBQVUsQ0FBQyxNQUFhLEVBQUMsSUFBVztRQUN2QyxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFBO1FBQ2xDLElBQUksR0FBRyxHQUFHLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUE7UUFDbEMsT0FBTyxJQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEVBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFBO0lBQzlDLENBQUM7SUFFRCxZQUFZLENBQUMsS0FBWTtRQUVyQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3BELElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNoRSxPQUFPLEtBQUssQ0FBQzthQUNiO1NBQ0Q7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNWLENBQUM7SUFFRCxJQUFJO1FBQ0EsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUE7SUFDaEMsQ0FBQztJQUVELFVBQVUsQ0FBQyxLQUFVO1FBRWpCLElBQUksQ0FBQyxHQUFHLFlBQVksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFBO1FBQ3RFLElBQUksQ0FBQyxHQUFHLFlBQVksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFBO1FBQzVFLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNaLENBQUM7SUFHRCxRQUFRLENBQUMsV0FBa0I7UUFDdkIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUE7SUFDekQsQ0FBQztJQUVELElBQUksQ0FBQyxJQUE2QjtRQUMvQixJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUE7UUFDdEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBQyxJQUFJLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQTtJQUNyRCxDQUFDO0lBRUQsTUFBTSxDQUFDLEdBQVU7UUFDYixJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUE7UUFDdEIsSUFBSSxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUE7UUFDbEIsSUFBSSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQTtJQUNyQyxDQUFDO0lBRUQsY0FBYyxDQUFDLEdBQVU7UUFDckIsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQTtRQUNyQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQTtJQUN0QyxDQUFDO0lBRUQsSUFBSSxDQUFDLFFBQXlCO1FBQzFCLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUE7UUFHdkIsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRTtZQUNsQixJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFBO1lBQ2xCLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFBO1lBQ2xCLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQTtRQUNsQixDQUFDLENBQUMsQ0FBQTtJQUNOLENBQUM7Q0FDSjtBQUVELFNBQVMsWUFBWSxDQUFDLE9BQWMsRUFBQyxPQUFjLEVBQUMsT0FBYyxFQUFDLE9BQWM7SUFDN0UsT0FBTyxPQUFPLElBQUksT0FBTyxJQUFJLE9BQU8sSUFBSSxPQUFPLENBQUE7QUFDbkQsQ0FBQztBQ3ZFRCxNQUFNLFVBQVU7SUFTWjtRQVJBLGNBQVMsR0FBRyxDQUFDLENBQUE7UUFHYixzQkFBaUIsR0FBRyxJQUFJLFdBQVcsRUFBTyxDQUFBO1FBQzFDLGlCQUFZLEdBQUcsSUFBSSxXQUFXLEVBQU8sQ0FBQTtRQUNyQyxVQUFLLEdBQThELEVBQUUsQ0FBQTtRQUNyRSx1QkFBa0IsR0FBRyxDQUFDLENBQUE7UUFHbEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUE7UUFDbkIsSUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFLENBQUE7SUFDcEIsQ0FBQztJQUVELGtGQUFrRjtJQUNsRix3RUFBd0U7SUFDeEUsOENBQThDO0lBQzlDLFNBQVM7SUFDVCxJQUFJO0lBRUoscUVBQXFFO0lBQ3JFLHlDQUF5QztJQUN6QyxJQUFJO0lBRUosZUFBZSxDQUFDLElBQVksRUFBRSxFQUFnQztRQUMxRCxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksRUFBQyxDQUFDLFNBQVMsRUFBRSxFQUFFO1lBQzNCLEVBQUUsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQTtRQUNuQyxDQUFDLENBQUMsQ0FBQTtJQUNOLENBQUM7SUFJRCxjQUFjLENBQUMsSUFBWSxFQUFFLElBQVMsRUFBRSxFQUF5QjtRQUM3RCxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQTtRQUV6QyxJQUFJLFVBQVUsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLG1CQUFtQixFQUFDLENBQUMsU0FBbUIsRUFBRSxFQUFFO1lBQ3JFLElBQUcsU0FBUyxDQUFDLElBQUksQ0FBQyxFQUFFLElBQUksU0FBUyxFQUFDO2dCQUM5QixJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFBO2dCQUN6QixFQUFFLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQTthQUMxQjtRQUNMLENBQUMsQ0FBQyxDQUFBO1FBQ0YsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEVBQUMsRUFBQyxJQUFJLEVBQUMsRUFBRSxFQUFFLFNBQVMsRUFBQyxDQUFDLENBQUE7SUFDakQsQ0FBQztJQUVELGlCQUFpQixDQUFDLElBQVMsRUFBRSxFQUFPO1FBQ2hDLElBQUksQ0FBQyxhQUFhLENBQUMsbUJBQW1CLEVBQUMsRUFBQyxJQUFJLEVBQUMsRUFBRSxFQUFDLENBQUMsQ0FBQTtJQUNyRCxDQUFDO0lBR0QsTUFBTSxDQUFDLElBQVcsRUFBQyxFQUFxQjtRQUNwQyxJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUE7UUFDekIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUM7WUFDaEIsRUFBRSxFQUFDLEVBQUU7WUFDTCxJQUFJLEVBQUUsSUFBSTtZQUNWLEVBQUU7U0FDTCxDQUFDLENBQUE7UUFDRixPQUFPLEVBQUUsQ0FBQTtJQUNiLENBQUM7SUFFRCxVQUFVLENBQUMsSUFBVyxFQUFDLEVBQXFCO1FBQ3hDLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFDLENBQUMsSUFBSSxFQUFFLEVBQUU7WUFDL0IsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQTtZQUNqQixFQUFFLENBQUMsSUFBSSxDQUFDLENBQUE7UUFDWixDQUFDLENBQUMsQ0FBQTtRQUNGLE9BQU8sRUFBRSxDQUFBO0lBQ2IsQ0FBQztJQUVELFFBQVEsQ0FBQyxFQUFTO1FBQ2QsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFBO1FBQ3JELElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBQyxDQUFDLENBQUMsQ0FBQTtJQUNsQyxDQUFDO0lBRUQsT0FBTztRQUVILE9BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFDO1lBQ3pCLElBQUksWUFBWSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUE7WUFDdEMsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQTtZQUV2RSxJQUFJLFdBQVcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksWUFBWSxDQUFDLElBQUksSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFLLENBQUMsQ0FBQTtZQUU3RyxJQUFHLFdBQVcsQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFDO2dCQUN2QixLQUFJLElBQUksUUFBUSxJQUFJLFNBQVMsRUFBQztvQkFDMUIsUUFBUSxDQUFDLEVBQUUsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUE7aUJBQ2pDO2FBQ0o7aUJBQUk7Z0JBQ0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUE7Z0JBQ3JDLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLEVBQUMsS0FBSyxFQUFDLFlBQVksRUFBQyxLQUFLLEVBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLEtBQUssRUFBQyxDQUFDLENBQUE7YUFDakY7U0FDSjtRQUNELElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUE7SUFDckMsQ0FBQztJQUVELEdBQUcsQ0FBQyxJQUFXLEVBQUMsSUFBUTtRQUNwQixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztZQUNiLElBQUksRUFBRSxJQUFJO1lBQ1YsSUFBSSxFQUFDLElBQUk7U0FDWixDQUFDLENBQUE7SUFDTixDQUFDO0lBRUQsYUFBYSxDQUFDLElBQVcsRUFBQyxJQUFRO1FBQzlCLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFDLElBQUksQ0FBQyxDQUFBO1FBQ25CLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQTtJQUNsQixDQUFDO0lBRUQsT0FBTyxDQUFDLElBQUksRUFBQyxLQUFLLEVBQUMsTUFBeUI7UUFDeEMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBQyxJQUFJLEVBQUMsS0FBSyxFQUFDLE1BQU0sRUFBQyxDQUFDLENBQUE7SUFDeEMsQ0FBQztDQUNKO0FDNUdELE1BQU0sV0FBVztJQUFqQjtRQUNJLGNBQVMsR0FBRyxDQUFDLENBQUE7UUFDYixjQUFTLEdBQTRDLEVBQUUsQ0FBQTtJQXFCM0QsQ0FBQztJQW5CRyxNQUFNLENBQUMsRUFBa0I7UUFDckIsSUFBSSxRQUFRLEdBQUc7WUFDWCxFQUFFLEVBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNuQixFQUFFLEVBQUMsRUFBRTtTQUNSLENBQUE7UUFDRCxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQTtRQUM3QixPQUFPLFFBQVEsQ0FBQyxFQUFFLENBQUE7SUFDdEIsQ0FBQztJQUVELFFBQVEsQ0FBQyxFQUFFO1FBQ1AsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFBO1FBQ3JELElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBQyxDQUFDLENBQUMsQ0FBQTtJQUNsQyxDQUFDO0lBRUQsT0FBTyxDQUFDLEdBQUs7UUFDVCxLQUFLLElBQUksUUFBUSxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDakMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQTtTQUNuQjtJQUNMLENBQUM7Q0FDSjtBQ3ZCRCxNQUFNLE1BQU07SUFLUixZQUFtQixJQUE2QjtRQUE3QixTQUFJLEdBQUosSUFBSSxDQUF5QjtRQUhoRCxRQUFHLEdBQVUsSUFBSSxNQUFNLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFBO1FBQzVCLFVBQUssR0FBVSxJQUFJLE1BQU0sQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUE7SUFJOUIsQ0FBQztJQUVELEtBQUs7UUFDRCxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUE7UUFDWCxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsd0JBQXdCLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQTtRQUNqRCxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7SUFDM0MsQ0FBQztJQUVELEdBQUc7UUFDQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUE7SUFDbEIsQ0FBQztJQUVELHdCQUF3QjtRQUNwQixJQUFJLENBQUMsR0FBRyxJQUFJLFNBQVMsQ0FBQztZQUNsQixDQUFDLEVBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEdBQUcsQ0FBQztTQUM5QyxDQUFDLENBQUE7UUFFRixJQUFJLENBQUMsR0FBRyxJQUFJLFNBQVMsQ0FBQztZQUNsQixJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUN0RCxDQUFDLENBQUE7UUFHRixPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUE7SUFDeEIsQ0FBQztJQUVELFlBQVksQ0FBQyxHQUFVO1FBQ25CLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyx3QkFBd0IsRUFBRSxDQUFDLGNBQWMsQ0FBQyxJQUFJLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFBO1FBQ3hGLE9BQU8sSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUE7SUFDNUMsQ0FBQztJQUVELFlBQVksQ0FBQyxHQUFVO1FBQ25CLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyx3QkFBd0IsRUFBRSxDQUFDLE9BQU8sRUFBRSxDQUFDLGNBQWMsQ0FBQyxJQUFJLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFBO1FBQ2xHLE9BQU8sSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUE7SUFDNUMsQ0FBQztDQUVKO0FDMUNELE1BQU0sU0FBUztJQVlYLFlBQW1CLElBQXdCO1FBVDNDLE9BQUUsR0FBVSxJQUFJLENBQUE7UUFDaEIsV0FBTSxHQUFVLElBQUksQ0FBQTtRQUNwQixTQUFJLEdBQVUsRUFBRSxDQUFBO1FBQ2hCLFNBQUksR0FBUyxFQUFFLENBQUE7UUFDZixhQUFRLEdBQVksRUFBRSxDQUFBO1FBQ3RCLGlCQUFpQjtRQUNqQixnQkFBZ0I7UUFDaEIsV0FBTSxHQUFHLEtBQUssQ0FBQTtRQUdWLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzFCLElBQUksQ0FBQyxJQUFJLEdBQUcsUUFBUSxDQUFBO0lBQ3hCLENBQUM7SUFFRCxRQUFRLENBQUMsS0FBZTtRQUNwQiw4QkFBOEI7UUFDOUIsSUFBSSxTQUFTLEdBQUcsU0FBUyxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUE7UUFDN0QsSUFBRyxTQUFTLElBQUksSUFBSSxFQUFDO1lBQ2pCLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQTtTQUN0QztRQUNELElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQTtRQUM1QixLQUFLLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxFQUFFLENBQUE7UUFDdEIsc0NBQXNDO0lBQzFDLENBQUM7SUFFRCxTQUFTLENBQUMsTUFBZ0I7UUFDdEIsSUFBRyxNQUFNLElBQUksSUFBSSxFQUFDO1lBQ2QsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUE7U0FDckI7YUFBSTtZQUNELE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUE7U0FDeEI7SUFDTCxDQUFDO0lBRUQsU0FBUztRQUNMLE9BQU8sU0FBUyxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUE7SUFDdkQsQ0FBQztJQUVELFVBQVUsQ0FBQyxFQUE2QjtRQUNwQyxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7SUFFbEMsQ0FBQztJQUVELFdBQVcsQ0FBQyxFQUE2QjtRQUNyQyxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFBO1FBQ2pDLElBQUksYUFBYSxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUE7UUFDNUQsT0FBTyxRQUFRLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFBO0lBQ3pDLENBQUM7SUFFRCxLQUFLLENBQUMsRUFBNkI7UUFDL0IsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFBO0lBQ2hDLENBQUM7SUFFRCxTQUFTLENBQUMsRUFBNkI7UUFDbkMsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUE7SUFDbEYsQ0FBQztJQUVELFdBQVc7UUFDUCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUE7SUFDckMsQ0FBQztJQUVELE1BQU07UUFDRixNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLFFBQVEsRUFBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUE7UUFDekMsU0FBUyxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUE7UUFDM0MsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFBO1FBQ3JCLE9BQU8sSUFBSSxDQUFBO0lBQ2YsQ0FBQztJQUVELE1BQU0sQ0FBQyxNQUFNO1FBQ1QsU0FBUyxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQTtRQUNyQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFBO1FBQ3RCLE9BQU8sSUFBSSxDQUFBO0lBQ2YsQ0FBQztJQUVELGNBQWM7UUFDVixJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUE7UUFDbkYsSUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUE7SUFDdEIsQ0FBQztJQUVELFFBQVEsQ0FBQyxFQUE2QjtRQUNsQyxJQUFJLE9BQU8sR0FBYSxJQUFJLENBQUE7UUFDNUIsT0FBTSxPQUFPLElBQUksSUFBSSxJQUFJLEVBQUUsQ0FBQyxPQUFPLENBQUMsSUFBSSxLQUFLLEVBQUM7WUFDMUMsT0FBTyxHQUFHLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFBO1NBQzVEO1FBQ0QsT0FBTyxPQUFPLENBQUE7SUFDbEIsQ0FBQztDQUNKO0FDeEZEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBaUpFO0FDaEpGLElBQUksWUFBWSxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQTtBQUVwQyxTQUFTLGNBQWM7SUFDbkIsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUE7QUFDN0IsQ0FBQztBQUVELFNBQVMsWUFBWSxDQUFDLE9BQU87SUFDekIsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUE7QUFDaEMsQ0FBQztBQUVELFNBQVMsVUFBVTtJQUNmLFlBQVksQ0FBQyxHQUFHLEVBQUUsQ0FBQTtBQUN0QixDQUFDO0FBR0QsU0FBUyxHQUFHLENBQUMsR0FBRyxFQUFDLFVBQVUsR0FBRyxFQUFFO0lBQzVCLEtBQUssRUFBRSxDQUFBO0lBQ1AsT0FBTyxFQUFFLENBQUMsR0FBRyxFQUFDLFVBQVUsQ0FBQyxDQUFBO0FBQzdCLENBQUM7QUFFRCxTQUFTLEVBQUUsQ0FBQyxHQUFHLEVBQUMsVUFBVSxHQUFHLEVBQUU7SUFDM0IsSUFBSSxNQUFNLEdBQUcsSUFBSSxFQUFFLENBQUE7SUFDbkIsSUFBSSxPQUFPLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQTtJQUN6QyxJQUFHLE1BQU0sRUFBQztRQUNOLE1BQU0sQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUE7S0FDOUI7SUFDRCxLQUFJLElBQUksR0FBRyxJQUFJLFVBQVUsRUFBQztRQUN0QixPQUFPLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQTtLQUM1QztJQUNELGNBQWMsRUFBRSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQTtJQUM5QixPQUFPLE9BQU8sQ0FBQTtBQUNsQixDQUFDO0FBRUQsU0FBUyxLQUFLLENBQUMsR0FBRyxFQUFDLFVBQVUsRUFBQyxVQUFVLEdBQUcsRUFBRTtJQUN6QyxFQUFFLENBQUMsR0FBRyxFQUFDLFVBQVUsQ0FBQyxDQUFBO0lBQ2xCLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQTtJQUNoQixPQUFPLEdBQUcsRUFBRSxDQUFBO0FBQ2hCLENBQUM7QUFFRCxTQUFTLElBQUksQ0FBQyxJQUFJO0lBQ2QsSUFBSSxFQUFFLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQTtJQUN6QixPQUFPLElBQUksRUFBRSxDQUFBO0FBQ2pCLENBQUM7QUFFRCxTQUFTLElBQUksQ0FBQyxJQUFJO0lBQ2QsSUFBSSxFQUFFLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQTtBQUMzQixDQUFDO0FBRUQsU0FBUyxHQUFHLENBQUMsVUFBVSxHQUFHLElBQUk7SUFDMUIsSUFBSSxhQUFhLEdBQUcsY0FBYyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUE7SUFDMUMsSUFBRyxVQUFVLElBQUksSUFBSSxJQUFJLFVBQVUsSUFBSSxhQUFhLEVBQUM7UUFDakQsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUMsZ0JBQWdCLEVBQUUsVUFBVSxDQUFDLENBQUE7S0FDM0Q7SUFDRCxPQUFPLGFBQWEsQ0FBQTtBQUN4QixDQUFDO0FBRUQsV0FBVyxDQUFDLFNBQVMsQ0FBQyxFQUFFLEdBQUcsVUFBUyxLQUFLLEVBQUMsRUFBRTtJQUN4QyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxFQUFDLEVBQUUsQ0FBQyxDQUFBO0lBQy9CLE9BQU8sSUFBSSxDQUFBO0FBQ2YsQ0FBQyxDQUFBO0FBRUQsU0FBUyxJQUFJO0lBQ1QsSUFBSSxPQUFPLEdBQUcsY0FBYyxFQUFFLENBQUE7SUFDOUIsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUE7QUFDeEIsQ0FBQztBQUVELFNBQVMsS0FBSztJQUNWLElBQUksT0FBTyxHQUFHLGNBQWMsRUFBRSxDQUFBO0lBQzlCLElBQUksSUFBSSxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQTtJQUNyQixPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQTtJQUNsQixPQUFPLElBQUksQ0FBQTtBQUNmLENBQUM7QUFFRCxTQUFTLEdBQUcsQ0FBQyxPQUFPLEdBQUcsRUFBRTtJQUNyQixPQUFPLEVBQUUsQ0FBQyxLQUFLLEVBQUMsT0FBTyxDQUFDLENBQUE7QUFDNUIsQ0FBQztBQUVELFNBQVMsQ0FBQyxDQUFDLE9BQU8sR0FBRyxFQUFFO0lBQ25CLE9BQU8sRUFBRSxDQUFDLEdBQUcsRUFBQyxPQUFPLENBQUMsQ0FBQTtBQUMxQixDQUFDO0FBRUQsU0FBUyxNQUFNLENBQUMsSUFBSSxFQUFDLE9BQU8sR0FBRyxFQUFFO0lBQzdCLE9BQU8sS0FBSyxDQUFDLFFBQVEsRUFBQyxJQUFJLEVBQUMsT0FBTyxDQUFDLENBQUE7QUFDdkMsQ0FBQztBQUVELFNBQVMsS0FBSyxDQUFDLE9BQU8sR0FBRyxFQUFFO0lBQ3ZCLE9BQU8sS0FBSyxDQUFDLE9BQU8sRUFBQyxPQUFPLENBQUMsQ0FBQTtBQUNqQyxDQUFDO0FBRUQsU0FBUyxHQUFHLENBQUMsT0FBTyxHQUFHLEVBQUU7SUFDckIsT0FBTyxLQUFLLENBQUMsS0FBSyxFQUFDLE9BQU8sQ0FBQyxDQUFBO0FBQy9CLENBQUM7QUFHRCxTQUFTLFlBQVksQ0FBRSxHQUFHO0lBQ3pCLElBQUksSUFBSSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLENBQUM7SUFFM0MsSUFBSSxDQUFDLFNBQVMsR0FBRyxHQUFHLENBQUM7SUFDckIsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQztBQUNuQyxDQUFDO0FBRUQsU0FBUyxXQUFXLENBQUMsTUFBTSxFQUFDLEtBQUs7SUFDN0IsSUFBRyxNQUFNLENBQUMsVUFBVSxFQUFDO1FBQ2pCLE1BQU0sQ0FBQyxZQUFZLENBQUMsS0FBSyxFQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQTtLQUMvQztTQUFJO1FBQ0QsTUFBTSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQTtLQUM1QjtBQUNMLENBQUM7QUFFRCxTQUFTLEVBQUUsQ0FBQyxPQUFPLEVBQUMsS0FBSztJQUNyQixJQUFHLE9BQU8sT0FBTyxJQUFJLFFBQVEsRUFBQztRQUMxQixPQUFPLFFBQVEsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFBO0tBQzlDO0lBQ0QsT0FBTyxPQUFPLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFBO0FBQ3ZDLENBQUM7QUFFRCxTQUFTLEdBQUcsQ0FBQyxPQUFPLEVBQUMsS0FBSztJQUN0QixPQUFPLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUE7QUFDdEQsQ0FBQztBQ3RIRCxTQUFTLFFBQVEsQ0FBQyxHQUFVLEVBQUMsS0FBYyxFQUFDLFFBQVEsR0FBRyxLQUFLLEVBQUMsS0FBSyxHQUFHLENBQUMsRUFBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO0lBQzNFLElBQUcsR0FBRyxJQUFJLENBQUMsQ0FBQyxFQUFDO1FBQ1QsR0FBRyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUE7S0FDckI7SUFDRCxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFBO0lBQ2IsSUFBSSxHQUFHLEdBQWlCLEVBQUUsQ0FBQTtJQUMxQixLQUFJLElBQUksQ0FBQyxHQUFHLEtBQUssRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sSUFBSSxDQUFDLEdBQUcsR0FBRyxFQUFDLENBQUMsRUFBRSxFQUFDO1FBQy9DLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxNQUFNLENBQU07WUFDekIsR0FBRyxFQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUU7WUFDWCxJQUFJLEVBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLEVBQUMsUUFBUSxDQUFDO1lBQ2hDLElBQUksRUFBQyxLQUFLO1lBQ1YsUUFBUSxDQUFDLElBQUk7WUFFYixDQUFDO1lBQ0QsTUFBTSxDQUFDLElBQUk7Z0JBQ1AsSUFBSSxHQUFHLEdBQU8sSUFBSSxDQUFDLElBQUksQ0FBQTtnQkFFdkIsSUFBSSxDQUFDLFNBQVMsR0FBRyxRQUFRLENBQUE7Z0JBQ3pCLElBQUksQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFBO2dCQUM1QixJQUFJLENBQUMsSUFBSSxHQUFHLFlBQVksQ0FBQTtnQkFDeEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFBO2dCQUM5QyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBQyxRQUFRLENBQUMsQ0FBQTtnQkFDM0IsSUFBSSxDQUFDLFNBQVMsR0FBRyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFBO2dCQUM5QyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxRQUFRLEVBQUUsRUFBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxRQUFRLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUE7WUFDM0YsQ0FBQztZQUNELElBQUksRUFBQyxJQUFJLEdBQUcsQ0FBQztnQkFDVCxLQUFLO2dCQUNMLEtBQUssRUFBQyxDQUFDO2FBQ1YsQ0FBQztTQUNMLENBQUMsQ0FBQyxDQUFBO1FBQ0gsSUFBRyxRQUFRLEVBQUM7WUFDUixHQUFHLENBQUMsQ0FBQyxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUE7U0FDdEI7YUFBSTtZQUNELEdBQUcsQ0FBQyxDQUFDLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQTtTQUN0QjtRQUNELEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUE7S0FDMUI7SUFDRCxPQUFPLEdBQUcsQ0FBQTtBQUNkLENBQUM7QUFFRCxTQUFTLFFBQVEsQ0FBQyxHQUFVLEVBQUMsSUFBVyxFQUFDLFFBQVEsR0FBQyxLQUFLO0lBQ25ELElBQUcsUUFBUSxFQUFDO1FBQ1IsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFBO0tBQ3pDO0lBQ0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUMsSUFBSSxDQUFDLENBQUMsR0FBSSxDQUFDLENBQUMsQ0FBQTtBQUNyRCxDQUFDO0FBRUQsTUFBTSxRQUFRO0lBS1YsWUFBWSxJQUFzQjtRQUM5QixNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksRUFBQyxJQUFJLENBQUMsQ0FBQTtJQUM1QixDQUFDO0NBQ0o7QUFFRCxTQUFTLGlCQUFpQixDQUFDLEdBQVU7SUFDakMsSUFBSSxRQUFRLEdBQUcsQ0FBQyxDQUFBO0lBRWhCLEtBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLEVBQUMsQ0FBQyxFQUFFLEVBQUM7UUFDdEIsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLE1BQU0sQ0FBQztZQUNwQixHQUFHLEVBQUMsR0FBRyxDQUFDLENBQUMsRUFBRTtZQUNYLFNBQVMsRUFBQyxJQUFJO1lBQ2QsUUFBUSxFQUFDLENBQUMsSUFBSSxFQUFFLEVBQUU7Z0JBQ2QsSUFBSSxRQUFRLEdBQVksSUFBSSxDQUFDLElBQUksQ0FBQTtnQkFDakMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQTtnQkFDbEQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQTtnQkFDOUMsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLENBQUE7Z0JBQ2pDLElBQUcsR0FBRyxHQUFHLFFBQVEsRUFBQztvQkFDZCxJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFBO2lCQUNoQztZQUNMLENBQUM7WUFDRCxNQUFNLEVBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRTtnQkFDWixJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBQyxJQUFJLENBQUMsQ0FBQTtnQkFDakMsSUFBSSxVQUFVLEdBQUcsV0FBVyxDQUFDLEdBQUcsRUFBQyxDQUFDLEVBQUMsUUFBUSxDQUFDLENBQUE7Z0JBQzVDLElBQUksQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFBO2dCQUN4QixJQUFJLENBQUMsSUFBSSxHQUFHLFlBQVksQ0FBQTtnQkFDeEIsSUFBSSxDQUFDLFdBQVcsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDLFVBQVUsRUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUE7Z0JBRTVDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQTtZQUN2RCxDQUFDO1lBQ0QsSUFBSSxFQUFDLElBQUksUUFBUSxDQUFDO2dCQUNkLEdBQUcsRUFBQyxJQUFJLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxFQUFDLEVBQUUsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEVBQUMsRUFBRSxDQUFDLENBQUM7Z0JBQ3BELEdBQUcsRUFBQyxJQUFJLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUNwQixJQUFJLEVBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsRUFBQyxHQUFHLENBQUMsQ0FBQzthQUM3QixDQUFDO1NBQ0wsQ0FBQyxDQUFDLENBQUE7S0FDTjtBQUNMLENBQUM7QUFFRCxTQUFTLGtCQUFrQixDQUFDLEdBQVUsRUFBQyxHQUFHO0lBQ3RDLElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQTtJQUNoQixLQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxFQUFDLENBQUMsRUFBRSxFQUFDO1FBQ3RCLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxNQUFNLENBQUM7WUFDcEIsR0FBRyxFQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUU7WUFDWCxTQUFTLEVBQUMsSUFBSTtZQUNkLFFBQVEsRUFBQyxDQUFDLElBQUksRUFBRSxFQUFFO2dCQUNkLElBQUksUUFBUSxHQUFZLElBQUksQ0FBQyxJQUFJLENBQUE7Z0JBQ2pDLFFBQVEsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUE7Z0JBQ2xELElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUE7Z0JBQzlDLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxDQUFBO2dCQUNqQyxJQUFHLEdBQUcsR0FBRyxRQUFRLEVBQUM7b0JBQ2QsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQTtpQkFDaEM7WUFDTCxDQUFDO1lBQ0QsTUFBTSxFQUFDLENBQUMsSUFBSSxFQUFFLEVBQUU7Z0JBQ1osSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLENBQUE7Z0JBQ2pDLElBQUksVUFBVSxHQUFHLFdBQVcsQ0FBQyxHQUFHLEVBQUMsQ0FBQyxFQUFDLFFBQVEsQ0FBQyxDQUFBO2dCQUM1QyxJQUFJLENBQUMsV0FBVyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUMsVUFBVSxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQTtnQkFFNUMsYUFBYSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUMsaUJBQWlCLEVBQUMsSUFBSSxDQUFDLENBQUE7WUFDbEQsQ0FBQztZQUNELElBQUksRUFBQyxJQUFJLFFBQVEsQ0FBQztnQkFDZCxHQUFHLEVBQUMsSUFBSSxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsRUFBQyxFQUFFLENBQUMsRUFBRSxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxFQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQzVFLEdBQUcsRUFBQyxJQUFJLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUM7YUFDekIsQ0FBQztTQUNMLENBQUMsQ0FBQyxDQUFBO0tBQ047QUFDTCxDQUFDO0FBR0QsU0FBUyxlQUFlLENBQUMsSUFBUyxFQUFDLElBQUk7SUFHbkMsT0FBTyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxxQkFBcUIsQ0FBQyxJQUFJLEVBQUMsSUFBSSxDQUFDLENBQUE7QUFDekUsQ0FBQztBQUVELFNBQVMsb0JBQW9CLENBQUMsSUFBUzs7SUFDbkMsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLE1BQU0sQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUE7SUFDN0QsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLE1BQU0sQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUE7SUFFN0QsS0FBSSxJQUFJLEtBQUssSUFBSSxRQUFRLENBQUMsTUFBTSxFQUFDO1FBQzdCLElBQUcsS0FBSyxDQUFDLElBQUksSUFBSSxhQUFhLEVBQUM7WUFDM0IsU0FBUTtTQUNYO1FBQ0QsS0FBSSxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBRSxFQUFDO1lBQzVCLEtBQUksSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUUsRUFBQztnQkFDNUIsSUFBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUM7b0JBQ2QsU0FBUTtpQkFDWDtnQkFDRCxJQUFJLEdBQUcsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFBO2dCQUN6QyxJQUFHLEdBQUcsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLFNBQVMsRUFBQztvQkFDNUIsU0FBUTtpQkFDWDtnQkFDRCxJQUFJLEVBQUMsR0FBRyxFQUFDLE9BQU8sRUFBQyxHQUFHLFNBQVMsQ0FBQyxHQUFHLEVBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFBO2dCQUNwRCxVQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLDBDQUFFLE9BQU8sRUFBQztvQkFDL0IsT0FBTyxJQUFJLENBQUE7aUJBQ2Q7YUFDSjtTQUNKO0tBQ0o7SUFFRCxPQUFPLEtBQUssQ0FBQTtBQUNoQixDQUFDO0FBR0QsU0FBUyxxQkFBcUIsQ0FBQyxJQUFTLEVBQUMsSUFBVztJQUNoRCxJQUFJLFFBQVEsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsQ0FBQTtJQUNsRCxLQUFJLElBQUksTUFBTSxJQUFJLFFBQVEsRUFBQztRQUN2QixJQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFDO1lBQzVCLE9BQU8sTUFBTSxDQUFBO1NBQ2hCO0tBQ0o7SUFDRCxPQUFPLElBQUksQ0FBQTtBQUNmLENBQUM7QUFHRCxTQUFTLFFBQVEsQ0FBQyxNQUFhLEVBQUMsS0FBSztJQUNqQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUE7SUFDWCxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFBO0lBQ2pDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxHQUFDLEdBQUcsQ0FBQyxDQUFBO0lBQ3RCLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFBO0FBQ3ZDLENBQUM7QUFFRCxTQUFTLE1BQU07SUFDWCxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUE7QUFDbEIsQ0FBQztBQUVELFNBQVMsU0FBUyxDQUFDLEtBQUssRUFBQyxHQUFVLEVBQUMsSUFBVyxFQUFDLFFBQVEsR0FBRyxLQUFLO0lBQzVELElBQUcsUUFBUSxFQUFDO1FBQ1IsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUE7S0FDOUI7SUFDRCxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBQyxHQUFHLENBQUMsQ0FBQyxFQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQTtBQUMzRCxDQUFDO0FBRUQsU0FBUyxVQUFVLENBQUMsS0FBSyxFQUFDLEdBQVEsRUFBQyxHQUFRO0lBQ3ZDLElBQUksT0FBTyxHQUFHLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQTtJQUN4QixJQUFJLE9BQU8sR0FBRyxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUE7SUFDeEIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUMsT0FBTyxDQUFDLENBQUMsRUFBQyxPQUFPLENBQUMsQ0FBQyxFQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFDLEdBQUcsRUFBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBQyxHQUFHLEVBQUMsT0FBTyxDQUFDLENBQUMsR0FBQyxDQUFDLEVBQUMsT0FBTyxDQUFDLENBQUMsR0FBQyxDQUFDLENBQUMsQ0FBQTtBQUNySCxDQUFDO0FBRUQsU0FBUyxTQUFTLENBQUMsR0FBRztJQUNsQixJQUFJLEtBQUssR0FBRyxJQUFJLEtBQUssRUFBRSxDQUFBO0lBQ3ZCLEtBQUssQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFBO0lBQ2YsT0FBTyxLQUFLLENBQUE7QUFDaEIsQ0FBQztBQUVELFNBQVMsWUFBWSxDQUFDLEtBQUssRUFBRSxLQUFLO0lBQzlCLE9BQU8sSUFBSSxNQUFNLENBQUMsS0FBSyxHQUFHLEtBQUssRUFBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQy9ELENBQUM7QUFFRCxTQUFTLFlBQVksQ0FBQyxDQUFDLEVBQUUsS0FBSztJQUMxQixPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0IsQ0FBQztBQUdELFNBQVMsS0FBSyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUMsQ0FBQztJQUNoQixPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQTtBQUNsRSxDQUFDO0FDbE5ELE1BQU0sR0FBRztJQUlMLFlBQVksSUFBaUI7UUFDekIsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUMsSUFBSSxDQUFDLENBQUE7SUFDNUIsQ0FBQztJQUVELEdBQUc7UUFDQyxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFBO0lBQ2pDLENBQUM7SUFFRCxHQUFHLENBQUMsR0FBRztRQUNILElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLEdBQUcsQ0FBQTtJQUNoQyxDQUFDO0lBRUQsSUFBSTtRQUNBLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFBO0lBQzVCLENBQUM7Q0FDSjtBQ25CRCxNQUFNLEtBQUs7SUFXUCxZQUFZLE9BQXNCO1FBVGxDLFNBQUksR0FBWSxFQUFFLENBQUE7UUFNbEIsYUFBUSxHQUFHLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFBO1FBYTFCLFVBQUssR0FBVTtZQUNYLElBQUksSUFBSSxDQUFDO2dCQUNMLElBQUksRUFBQyxRQUFRO2dCQUNiLElBQUksRUFBQyxDQUFDO2FBQ1QsQ0FBQztZQUNGLElBQUksSUFBSSxDQUFDO2dCQUNMLElBQUksRUFBQyxPQUFPO2dCQUNaLElBQUksRUFBQyxDQUFDO2FBQ1QsQ0FBQztZQUNGLElBQUksSUFBSSxDQUFDO2dCQUNMLElBQUksRUFBQyxRQUFRO2dCQUNiLElBQUksRUFBQyxDQUFDO2FBQ1QsQ0FBQztTQUVMLENBQUE7UUF2QkcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUMsT0FBTyxDQUFDLENBQUE7UUFDM0IsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLEtBQUssQ0FBUyxFQUFFLENBQUMsQ0FBQTtRQUNqQyxLQUFJLElBQUksR0FBRyxJQUFJLE9BQU8sRUFBQztZQUNuQixJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQTtTQUNqQztJQUNMLENBQUM7SUFxQkQsT0FBTyxDQUFDLElBQUksRUFBQyxLQUFLO1FBQ2QsSUFBSSxNQUFNLEdBQUcsQ0FBQyxDQUFBO1FBQ2QsS0FBSSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsS0FBSyxFQUFDO1lBQ3ZCLElBQUcsSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLEVBQUM7Z0JBQ2pCLElBQUksSUFBSSxHQUFHLFdBQVcsQ0FBQyxLQUFLLEVBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFBO2dCQUN2QyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUMsSUFBSSxDQUFDLElBQUksRUFBQyxHQUFHLElBQUksQ0FBQyxDQUFBO2FBQzdDO1lBQ0QsTUFBTSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUE7U0FDdEI7SUFDTCxDQUFDO0lBRUQsT0FBTyxDQUFDLElBQUk7UUFDUixJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUE7UUFDZCxLQUFJLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxLQUFLLEVBQUM7WUFDdkIsSUFBRyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksRUFBQztnQkFDakIsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUE7Z0JBQ3JELE9BQU8sV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFBO2FBQzNCO1lBQ0QsTUFBTSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUE7U0FDdEI7SUFDTCxDQUFDO0NBQ0o7QUMzREQsTUFBTSxRQUFRO0lBSVYsWUFBWSxXQUFXO1FBQ25CLElBQUksQ0FBQyxRQUFRLEdBQUcsQ0FBQyxDQUFBO1FBQ2pCLElBQUksQ0FBQyxXQUFXLEdBQUcsV0FBVyxDQUFBO0lBQ2xDLENBQUM7SUFFRCxPQUFPO1FBQ0gsT0FBTyxJQUFJLENBQUMsUUFBUSxJQUFJLENBQUMsQ0FBQTtJQUM3QixDQUFDO0lBRUQsT0FBTztRQUNILElBQUcsSUFBSSxDQUFDLE9BQU8sRUFBRSxFQUFDO1lBQ2QsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFBO1lBQ2hDLE9BQU8sSUFBSSxDQUFBO1NBQ2Q7UUFDRCxPQUFPLEtBQUssQ0FBQTtJQUNoQixDQUFDO0lBRUQsTUFBTSxDQUFDLEVBQUU7UUFDTCxJQUFJLENBQUMsUUFBUSxJQUFJLEVBQUUsQ0FBQTtRQUNuQixJQUFHLElBQUksQ0FBQyxRQUFRLEdBQUcsQ0FBQyxFQUFDO1lBQ2pCLElBQUksQ0FBQyxRQUFRLEdBQUcsQ0FBQyxDQUFBO1NBQ3BCO0lBQ0wsQ0FBQztDQUNKO0FDM0JELE1BQU0sSUFBSTtJQUlOLFlBQVksSUFBa0I7UUFDMUIsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUMsSUFBSSxDQUFDLENBQUE7SUFDNUIsQ0FBQztDQUNKO0FBRUQsTUFBTSxHQUFHO0lBUUwsWUFBWSxPQUFvQjtRQU5oQyxTQUFJLEdBQVksRUFBRSxDQUFBO1FBZWxCLFVBQUssR0FBVTtZQUNYLElBQUksSUFBSSxDQUFDO2dCQUNMLElBQUksRUFBQyxNQUFNO2dCQUNYLElBQUksRUFBQyxDQUFDO2FBQ1QsQ0FBQztZQUNGLElBQUksSUFBSSxDQUFDO2dCQUNMLElBQUksRUFBQyxVQUFVO2dCQUNmLElBQUksRUFBQyxDQUFDO2FBQ1QsQ0FBQztTQUNMLENBQUE7UUFqQkcsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLEtBQUssQ0FBUyxFQUFFLENBQUMsQ0FBQTtRQUNqQyxLQUFJLElBQUksR0FBRyxJQUFJLE9BQU8sRUFBQztZQUNuQixJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQTtTQUNqQztJQUNMLENBQUM7SUFpQkQsR0FBRyxDQUFDLElBQUk7UUFDSixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksRUFBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFBO0lBQzdDLENBQUM7SUFFRCxJQUFJLENBQUMsSUFBSTtRQUNMLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUE7SUFDN0MsQ0FBQztJQUVELE9BQU8sQ0FBQyxJQUFJLEVBQUMsS0FBSztRQUNkLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxLQUFLLENBQUE7UUFDbEIsSUFBSSxNQUFNLEdBQUcsQ0FBQyxDQUFBO1FBQ2QsS0FBSSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsS0FBSyxFQUFDO1lBQ3ZCLElBQUcsSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLEVBQUM7Z0JBQ2pCLElBQUksSUFBSSxHQUFHLFdBQVcsQ0FBQyxLQUFLLEVBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFBO2dCQUN2QyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUMsSUFBSSxDQUFDLElBQUksRUFBQyxHQUFHLElBQUksQ0FBQyxDQUFBO2FBQzdDO1lBQ0QsTUFBTSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUE7U0FDdEI7SUFDTCxDQUFDO0lBRUQsT0FBTyxDQUFDLElBQUk7UUFDUixJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUE7UUFDZCxLQUFJLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxLQUFLLEVBQUM7WUFDdkIsSUFBRyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksRUFBQztnQkFDakIsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQTtnQkFDNUMsT0FBTyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUE7YUFDM0I7WUFDRCxNQUFNLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQTtTQUN0QjtJQUNMLENBQUM7Q0FDSjtBQUVELFNBQVMsV0FBVyxDQUFDLE1BQU0sRUFBQyxPQUFPO0lBRS9CLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQztJQUNiLEtBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFDLENBQUMsR0FBRyxPQUFPLEVBQUUsQ0FBQyxFQUFFLEVBQUU7UUFDNUIsR0FBRyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN0QyxNQUFNLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7S0FDbkM7SUFFRCxPQUFPLEdBQUcsQ0FBQztBQUNmLENBQUM7QUFFRCxTQUFTLFdBQVcsQ0FBQyxJQUFhO0lBQzlCLElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQTtJQUNYLEtBQUksSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFDLENBQUMsRUFBRSxFQUFDO1FBQy9DLElBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBQztZQUNaLEdBQUcsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQTtTQUN2QjtLQUNKO0lBQ0QsT0FBTyxHQUFHLENBQUE7QUFDZCxDQUFDO0FDMUZELE1BQU0sTUFBTTtJQWNSLFlBQVksSUFBdUI7UUFMbkMsc0JBQWlCLEdBQVcsS0FBSyxDQUFBO1FBTTdCLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFDLElBQUksQ0FBQyxDQUFBO0lBQzVCLENBQUM7Q0FDSjtBQ2hCRCxNQUFNLGVBQWU7SUFFakIsWUFBWSxJQUE2QjtRQUNyQyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksRUFBQyxJQUFJLENBQUMsQ0FBQTtJQUM1QixDQUFDO0NBWUo7QUFFRCxTQUFTLGFBQWEsQ0FBQyxHQUFVLEVBQUMsU0FBeUIsRUFBQyxJQUFJLEVBQUMsS0FBSyxHQUFHLEtBQUssRUFBQyxRQUFRLEdBQUcsSUFBSTtJQUMxRixJQUFHLFFBQVEsRUFBQztRQUNSLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUE7S0FDekQ7SUFDRCxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEdBQUcsU0FBUyxDQUFDLFFBQVEsRUFBQyxDQUFDLEVBQUMsU0FBUyxDQUFDLFFBQVEsRUFBQyxDQUFDLEVBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUE7SUFDbEcsSUFBRyxLQUFLLEVBQUM7UUFDTCxJQUFJLE1BQU0sR0FBRyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUE7UUFDN0QsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFBO1FBQ1gsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQTtRQUNqQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFBO1FBQ2hCLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFBO0tBRXRDO0lBQ0QsY0FBYyxDQUFDLEdBQUcsRUFBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFBO0lBQzlILElBQUcsS0FBSyxFQUFDO1FBQ0wsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFBO0tBQ2pCO0FBQ0wsQ0FBQztBQUVELFNBQVMsY0FBYyxDQUFDLFNBQWdCLEVBQUMsT0FBYyxFQUFDLFFBQWUsRUFBQyxLQUFLO0lBQ3pFLElBQUksTUFBTSxHQUFHLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUE7SUFDdEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUMsTUFBTSxDQUFDLENBQUMsRUFBQyxNQUFNLENBQUMsQ0FBQyxFQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUMsUUFBUSxDQUFDLENBQUMsRUFBQyxTQUFTLENBQUMsQ0FBQyxFQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUMsUUFBUSxDQUFDLENBQUMsRUFBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUE7QUFDL0csQ0FBQztBQ3hDRCxNQUFNLE1BQU07SUFZUixZQUFZLElBQW9CO1FBWGhDLFdBQU0sR0FBRyxLQUFLLENBQUE7UUFDZCxXQUFNLEdBQUcsQ0FBQyxDQUFBO1FBQ1YsZUFBVSxHQUFHLEtBQUssQ0FBQTtRQUVsQixnQkFBVyxHQUFHLElBQUksUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFBO1FBQy9CLFFBQUcsR0FBRyxJQUFJLEdBQUcsQ0FBQztZQUNWLElBQUksRUFBQyxNQUFNO1lBQ1gsUUFBUSxFQUFDLE1BQU07WUFDZixXQUFXLEVBQUMsS0FBSztTQUNwQixDQUFDLENBQUE7UUFHRSxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksRUFBQyxJQUFJLENBQUMsQ0FBQTtJQUM1QixDQUFDO0NBQ0o7QUFHRCxTQUFTLFFBQVEsQ0FBQyxJQUFtQjtJQUNqQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUE7SUFHdEMsSUFBRyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxFQUFDO1FBQ2hHLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQTtRQUM1QixJQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFDO1lBQ3RCLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQTtTQUNwQjthQUFJO1lBQ0QsYUFBYSxDQUFDLElBQUksRUFBRSxDQUFBO1NBQ3ZCO1FBRUQsSUFBSSxLQUFLLEdBQUcsTUFBTSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQTtRQUN6QyxJQUFJLFdBQVcsR0FBRyxHQUFHLENBQUM7UUFDdEIsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLE1BQU0sQ0FBUztZQUM1QixHQUFHLEVBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUU7WUFDbEIsSUFBSSxFQUFDLFFBQVE7WUFDYixTQUFTLEVBQUMsSUFBSTtZQUNkLFFBQVEsQ0FBQyxJQUFJO2dCQUNULElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFDLElBQUksQ0FBQyxDQUFBO2dCQUNqQyxJQUFHLEdBQUcsR0FBRyxDQUFDLEVBQUM7b0JBQ1AsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQTtvQkFDN0IsT0FBTTtpQkFDVDtnQkFDRCxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQTtnQkFFL0MsSUFBSSxVQUFVLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLElBQUksTUFBTSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFBO2dCQUMzRCxJQUFJLE1BQU0sR0FBZSxxQkFBcUIsQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUE7Z0JBQ2pFLElBQUksUUFBUSxHQUFpQixxQkFBcUIsQ0FBQyxVQUFVLEVBQUUsT0FBTyxDQUFDLENBQUE7Z0JBRXZFLElBQUcsb0JBQW9CLENBQUMsVUFBVSxDQUFDLEVBQUM7b0JBQ2hDLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUE7aUJBQ2hDO2dCQUNELElBQUcsTUFBTSxFQUFDO29CQUNOLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUE7b0JBQzdCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUE7aUJBQ3JCO2dCQUNELElBQUcsUUFBUSxFQUFDO29CQUNSLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQSxDQUFBLHNCQUFzQjtvQkFDMUYsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQTtvQkFDN0IsSUFBRyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUM7d0JBQ3BDLFFBQVEsQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUE7d0JBQ2pDLGdCQUFnQjt3QkFDaEIsWUFBWTtxQkFDZjtpQkFDSjtnQkFDRCxJQUFHLElBQUksQ0FBQyxpQkFBaUIsRUFBQztvQkFDdEIsSUFBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBQzt3QkFDckIsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFBO3FCQUM5Qjt5QkFBSTt3QkFDRCxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUE7cUJBQzdDO2lCQUNKO1lBQ0wsQ0FBQztZQUNELE1BQU0sQ0FBQyxJQUFJO2dCQUNQLElBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUM7b0JBQ3JCLElBQUksQ0FBQyxJQUFJLEdBQUcsWUFBWSxDQUFBO29CQUN4QixJQUFJLENBQUMsU0FBUyxHQUFHLE9BQU8sQ0FBQTtvQkFDeEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLEVBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQTtpQkFDM0M7cUJBQUk7b0JBQ0QsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUE7b0JBQ3RCLGFBQWEsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFDLGlCQUFpQixFQUFDLElBQUksRUFBQyxLQUFLLEVBQUMsSUFBSSxDQUFDLENBQUE7b0JBQ3pELDBDQUEwQztpQkFDN0M7WUFDTCxDQUFDO1lBQ0QsSUFBSSxFQUFDO2dCQUNELEdBQUcsRUFBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDO2dCQUN2RCxXQUFXLEVBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVO2FBQ3JDO1NBQ0osQ0FBQyxDQUFDLENBQUE7UUFDSCxVQUFVO1FBQ1YsZ0JBQWdCO1FBQ2hCLGNBQWM7UUFFZCxzQ0FBc0M7UUFDdEMsRUFBRTtLQUNMO0FBRUwsQ0FBQztBQ2hHRCxTQUFTLFdBQVcsQ0FBQyxTQUFTO0lBRTFCLDJDQUEyQztJQUMzQyxvREFBb0Q7SUFDcEQsSUFBSSxFQUFFLEdBQUcsTUFBTSxDQUFDLFlBQVksQ0FBQyxJQUFJLE1BQU0sQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFBO0lBQzdFLElBQUksRUFBRSxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsVUFBVSxDQUFDLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQTtJQUN4RSxFQUFFLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLEVBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFBO0lBQ2xCLEVBQUUsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsRUFBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUE7SUFDbEIsRUFBRSxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQTtJQUNwQyxFQUFFLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFBO0lBRXBDLEtBQUksSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUUsRUFBQztRQUM1QixLQUFJLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFFLEVBQUM7WUFDNUIsSUFBSSxLQUFLLEdBQUcsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQTtZQUNwQyxLQUFJLElBQUksS0FBSyxJQUFJLFNBQVMsQ0FBQyxNQUFNLEVBQUM7Z0JBQzlCLElBQUcsS0FBSyxDQUFDLElBQUksRUFBQztvQkFDVixJQUFJLEdBQUcsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFBO29CQUMzQixJQUFHLEdBQUcsSUFBSSxDQUFDLEVBQUM7d0JBQ1IsU0FBUTtxQkFDWDtvQkFDRCxJQUFJLHlCQUF5QixHQUFJLFVBQVUsQ0FBQztvQkFDNUMsSUFBSSx1QkFBdUIsR0FBTSxVQUFVLENBQUM7b0JBQzVDLElBQUksdUJBQXVCLEdBQU0sVUFBVSxDQUFDO29CQUM1QyxJQUFJLDBCQUEwQixHQUFHLFVBQVUsQ0FBQztvQkFFNUMsSUFBSSxPQUFPLEdBQUcsR0FBRyxHQUFHLHlCQUF5QixDQUFDO29CQUM5QyxJQUFJLE9BQU8sR0FBRyxHQUFHLEdBQUcsdUJBQXVCLENBQUE7b0JBQzNDLElBQUksUUFBUSxHQUFHLEdBQUcsR0FBRyx1QkFBdUIsQ0FBQTtvQkFDNUMsSUFBSSxPQUFPLEdBQUcsR0FBRyxHQUFHLDBCQUEwQixDQUFBO29CQUM5QyxHQUFHLElBQUksQ0FBQyxDQUFDLHlCQUF5Qjt3QkFDOUIsdUJBQXVCO3dCQUN2Qix1QkFBdUI7d0JBQ3ZCLDBCQUEwQixDQUFDLENBQUM7b0JBRWhDLDRCQUE0QjtvQkFFNUIsSUFBSSxFQUFDLEdBQUcsRUFBQyxPQUFPLEVBQUMsR0FBRyxTQUFTLENBQUMsR0FBRyxFQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQTtvQkFDckQsSUFBSSxJQUFJLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQTtvQkFDakMsSUFBRyxJQUFJLGFBQUosSUFBSSx1QkFBSixJQUFJLENBQUUsU0FBUyxFQUFDO3dCQUNmLElBQUksWUFBWSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFBO3dCQUMxRSxJQUFJLFNBQVMsR0FBRyxJQUFJLEdBQUcsWUFBWSxDQUFBO3dCQUNuQyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsR0FBRyxHQUFHLENBQUMsQ0FBQTt3QkFDdkMsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFBO3FCQUNyQztvQkFFRCxJQUFJLFNBQVMsR0FBRyxZQUFZLENBQUMsR0FBRyxFQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUN4RSxJQUFJLFNBQVMsR0FBRyxZQUFZLENBQUMsS0FBSyxFQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDM0UsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUN6RCxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsRUFBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBRXhELGVBQWU7b0JBQ2YsMEJBQTBCO29CQUMxQixJQUFJO29CQUNKLGVBQWU7b0JBQ2YsMkJBQTJCO29CQUMzQixJQUFJO29CQUNKLGdCQUFnQjtvQkFDaEIsa0ZBQWtGO29CQUNsRixJQUFJO29CQUNKLFVBQVUsQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFDLE9BQU8sRUFBQyxPQUFPLENBQUMsQ0FBQTtpQkFDOUM7Z0JBRUQsSUFBRyxLQUFLLENBQUMsT0FBTyxFQUFDO29CQUNiLEtBQUksSUFBSSxNQUFNLElBQUksS0FBSyxDQUFDLE9BQU8sRUFBQzt3QkFDNUIsSUFBRyxNQUFNLENBQUMsSUFBSSxFQUFDOzRCQUNYLElBQUksQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFBOzRCQUN4QixJQUFJLENBQUMsSUFBSSxHQUFHLFlBQVksQ0FBQTs0QkFDeEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksRUFBQyxNQUFNLENBQUMsQ0FBQyxFQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQTt5QkFDcEQ7NkJBQUk7NEJBQ0QsSUFBRyxpQkFBaUIsRUFBQztnQ0FDakIsSUFBSSxDQUFDLFNBQVMsR0FBRyxPQUFPLENBQUE7Z0NBQ3hCLFFBQVEsQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFDLFNBQVMsQ0FBQyxRQUFRLEVBQUMsSUFBSSxDQUFDLENBQUE7NkJBQy9DO3lCQUNKO3FCQUNKO2lCQUNKO2FBQ0o7U0FFSjtLQUNKO0FBQ0wsQ0FBQztBQUdELFNBQVMsa0JBQWtCLENBQUMsUUFBUTs7SUFDaEMsUUFBUSxDQUFDLFFBQVEsR0FBRyxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsU0FBUyxFQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQTtJQUN0RSxRQUFRLENBQUMsSUFBSSxHQUFHLElBQUksTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUFLLEVBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFBO0lBRTFELEtBQUksSUFBSSxLQUFLLElBQUksUUFBUSxDQUFDLE1BQU0sRUFBQztRQUM3QixJQUFHLEtBQUssQ0FBQyxJQUFJLEVBQUM7WUFDVixLQUFLLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUE7U0FDcEM7UUFFRCxJQUFHLEtBQUssQ0FBQyxPQUFPLEVBQUM7WUFDYixLQUFJLElBQUksTUFBTSxJQUFJLEtBQUssQ0FBQyxPQUFPLEVBQUM7Z0JBQzVCLE1BQU0sQ0FBQyxHQUFHLEdBQUcsSUFBSSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUE7Z0JBQzFDLE1BQU0sQ0FBQyxJQUFJLEdBQUcsSUFBSSxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUE7Z0JBQ3BELGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQTthQUMxQjtTQUNKO0tBQ0o7SUFFRCxLQUFJLElBQUksT0FBTyxJQUFJLFFBQVEsQ0FBQyxRQUFRLEVBQUM7UUFDakMsT0FBTyxDQUFDLE9BQU8sR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFBO1FBQzFDLE9BQU8sQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFBO1FBQ3RCLE9BQU8sQ0FBQyxRQUFRLEdBQUcsSUFBSSxNQUFNLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUE7UUFDbkUsS0FBSSxJQUFJLElBQUksVUFBSSxPQUFPLENBQUMsS0FBSyxtQ0FBSSxFQUFFLEVBQUM7WUFDaEMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFBO1lBQ2pDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQTtTQUN4QjtLQUNKO0FBQ0wsQ0FBQztBQUVELFNBQVMsU0FBUyxDQUFDLEdBQUcsRUFBQyxRQUFRO0lBQzNCLEtBQUksSUFBSSxDQUFDLEdBQUcsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBQztRQUN6QyxJQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLElBQUksR0FBRyxFQUFDO1lBQzNCLE9BQU87Z0JBQ0gsT0FBTyxFQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7Z0JBQ25CLEdBQUcsRUFBQyxHQUFHLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVE7YUFDakMsQ0FBQTtTQUNKO0tBQ0o7QUFDTCxDQUFDO0FBRUQsU0FBUyxlQUFlLENBQUMsTUFBTTtJQUMzQixJQUFHLE1BQU0sQ0FBQyxVQUFVLEVBQUM7UUFDakIsS0FBSSxJQUFJLElBQUksSUFBSSxNQUFNLENBQUMsVUFBVSxFQUFDO1lBQzlCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQTtTQUNqQztLQUNKO0FBQ0wsQ0FBQztBQ2pJRCxrRUFBa0U7QUFDbEUsOENBQThDO0FBQzlDLDhDQUE4QztBQUM5QyxrRUFBa0U7QUFDbEUsOENBQThDO0FBSTlDLFNBQVMsVUFBVTtJQUdmLHlCQUF5QjtJQUN6QixzQ0FBc0M7SUFFdEMsaUJBQWlCLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxFQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsRUFBQyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLEVBQUMsR0FBRyxFQUFDLENBQUMsQ0FBQyxDQUFBO0lBQ3ZILGlCQUFpQixFQUFFLENBQUE7SUFDbkIsYUFBYSxFQUFFLENBQUE7SUFDZixTQUFTLEVBQUUsQ0FBQTtJQUNYLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxNQUFNLENBQUM7UUFDcEIsUUFBUSxDQUFDLElBQUk7WUFDVCxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFDLENBQUMsQ0FBQyxDQUFBO1FBQ3JDLENBQUM7S0FDSixDQUFDLENBQUMsQ0FBQTtBQUNQLENBQUM7QUFFRCxTQUFTLGlCQUFpQjtJQUN0QixNQUFNLENBQUMsR0FBRyxHQUFHLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQTtBQUN0RCxDQUFDO0FBRUQsU0FBUyxhQUFhO0lBQ2xCLElBQUksVUFBVSxHQUFHLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFBO0lBQ2hDLEtBQUksSUFBSSxNQUFNLElBQUksaUJBQWlCLENBQUMsWUFBWSxDQUFDLEVBQUM7UUFDOUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLE1BQU0sQ0FBQztZQUNwQixJQUFJLEVBQUMsWUFBWTtZQUNqQixHQUFHLEVBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUU7WUFDbEIsSUFBSSxFQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsRUFBQyxRQUFRLENBQUM7WUFDN0MsUUFBUSxDQUFDLElBQUk7Z0JBQ1QsVUFBVSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQTtnQkFDM0IsSUFBRyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksVUFBVSxDQUFDLE9BQU8sRUFBRSxFQUFDO29CQUN6RCxhQUFhLENBQUMsSUFBSSxFQUFFLENBQUE7b0JBQ3BCLE1BQU0sQ0FBQyxHQUFHLEdBQUcsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQTtvQkFDakQsTUFBTSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFBO29CQUN0QyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFBO29CQUVoRCxJQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFDO3dCQUN0QixRQUFRLENBQUMsSUFBSSxFQUFFLENBQUE7d0JBQ2YsV0FBVyxDQUFDLEtBQUssRUFBRSxDQUFBO3FCQUN0Qjt5QkFBSTt3QkFDRCxRQUFRLENBQUMsS0FBSyxFQUFFLENBQUE7d0JBQ2hCLFdBQVcsQ0FBQyxJQUFJLEVBQUUsQ0FBQTtxQkFDckI7aUJBQ0o7WUFDTCxDQUFDO1lBQ0QsTUFBTSxDQUFDLElBQUk7Z0JBQ1AsY0FBYyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFDLElBQUksTUFBTSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxRQUFRLEVBQUMsV0FBVyxDQUFDLENBQUE7WUFDbkYsQ0FBQztTQUNKLENBQUMsQ0FBQyxDQUFBO0tBQ047QUFDTCxDQUFDO0FBRUQsU0FBUyxTQUFTO0lBQ2QsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFBO0lBQ1osS0FBSSxJQUFJLFVBQVUsSUFBSSxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsRUFBQztRQUM1QyxJQUFJLE9BQU8sR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFBO1FBQzVCLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxNQUFNLENBQUM7WUFDcEIsSUFBSSxFQUFDLE1BQU07WUFDWCxHQUFHLEVBQUMsT0FBTztZQUNYLElBQUksRUFBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBQyxRQUFRLENBQUM7WUFDdEMsUUFBUSxDQUFDLElBQUk7Z0JBQ1QsSUFBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBQztvQkFDcEIsSUFBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUM7d0JBQ3RELFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFBO3dCQUMvQixhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxJQUFJLENBQUE7cUJBQzNDO2lCQUNKO3FCQUFLLElBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFDO29CQUN2QyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQTtvQkFDL0IsYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsSUFBSSxDQUFBO2lCQUMzQztZQUNMLENBQUM7WUFDRCxNQUFNLENBQUMsSUFBSTtnQkFDUCxJQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFDO29CQUN6QyxjQUFjLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUMsSUFBSSxNQUFNLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFDLFFBQVEsRUFBQyxXQUFXLENBQUMsQ0FBQTtpQkFDbEY7cUJBQUk7b0JBQ0QsY0FBYyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFDLElBQUksTUFBTSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsRUFBQyxRQUFRLEVBQUMsV0FBVyxDQUFDLENBQUE7aUJBQ2xGO2dCQUNELG1DQUFtQztZQUN2QyxDQUFDO1lBQ0QsSUFBSSxFQUFDLFVBQVU7U0FDbEIsQ0FBQyxDQUFDLENBQUE7UUFDSCxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFBO0tBQzFCO0lBQ0QsT0FBTyxHQUFHLENBQUE7QUFDZCxDQUFDO0FBS0QsU0FBUyxXQUFXLENBQUMsS0FBSztJQUN0QixlQUFlO0lBQ2YsT0FBTyxHQUFHLEVBQUUsQ0FBQTtJQUNaLFFBQVEsR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUE7SUFDeEIsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUE7SUFDM0Qsa0JBQWtCLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQTtBQUMvQixDQUFDO0FBRUQsU0FBUyxpQkFBaUIsQ0FBQyxPQUFjLEVBQUMsT0FBYyxFQUFDLFdBQWtCLEVBQUMsT0FBYyxFQUFDLFFBQVE7SUFDL0YsSUFBSSxHQUFHLEdBQWlCLEVBQUUsQ0FBQTtJQUMxQixPQUFPLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxNQUFNLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFO1FBQzVELElBQUksTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUE7UUFDaEMsSUFBSSxNQUFNLEdBQUcsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQTtRQUNwQyxJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsRUFBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUE7UUFDakUsSUFBSSxHQUFHLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUE7UUFDeEMsSUFBRyxHQUFHLElBQUksT0FBTyxFQUFDO1lBQ2QsT0FBTTtTQUNUO1FBQ0QsSUFBSSxNQUFNLEdBQUcsV0FBVyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUE7UUFDckQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLE1BQU0sQ0FBTTtZQUN6QixHQUFHLEVBQUMsTUFBTTtZQUNWLElBQUksRUFBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBQyxRQUFRLENBQUM7WUFDbkMsSUFBSSxFQUFDLEtBQUs7WUFDVixRQUFRLENBQUMsSUFBSTtnQkFDVCxJQUFJLEtBQUssR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsRUFBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUE7Z0JBQ2pFLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQTtZQUM5RSxDQUFDO1lBQ0QsTUFBTSxDQUFDLElBQUk7Z0JBQ1AsSUFBSSxHQUFHLEdBQU8sSUFBSSxDQUFDLElBQUksQ0FBQTtnQkFDdkIsSUFBSSxDQUFDLFNBQVMsR0FBRyxRQUFRLENBQUE7Z0JBQ3pCLElBQUksQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFBO2dCQUM1QixJQUFJLENBQUMsSUFBSSxHQUFHLFlBQVksQ0FBQTtnQkFDeEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFBO2dCQUM5QyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBQyxRQUFRLENBQUMsQ0FBQTtnQkFDM0IsSUFBSSxDQUFDLFNBQVMsR0FBRyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFBO2dCQUM5QyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxRQUFRLEVBQUUsRUFBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxRQUFRLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUE7WUFDM0YsQ0FBQztZQUNELElBQUksRUFBQyxJQUFJLEdBQUcsQ0FBQztnQkFDVCxLQUFLLEVBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ1QsS0FBSyxFQUFDLENBQUM7YUFDVixDQUFDO1NBQ0wsQ0FBQyxDQUFDLENBQUE7UUFDSCxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFBO0lBQzNCLENBQUMsQ0FBQyxDQUFBO0lBRUYsT0FBTyxHQUFHLENBQUE7QUFDZCxDQUFDO0FBRUQsU0FBUyxpQkFBaUIsQ0FBQyxJQUFJOztJQUMzQixJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUE7SUFDWixLQUFJLElBQUksS0FBSyxJQUFJLFFBQVEsQ0FBQyxNQUFNLEVBQUM7UUFDN0IsS0FBSSxJQUFJLE1BQU0sVUFBSSxLQUFLLENBQUMsT0FBTyxtQ0FBSSxFQUFFLEVBQUM7WUFDbEMsSUFBRyxNQUFNLENBQUMsS0FBSyxJQUFJLElBQUksRUFBQztnQkFDcEIsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQTthQUNuQjtTQUNKO0tBQ0o7SUFDRCxPQUFPLEdBQUcsQ0FBQTtBQUNkLENBQUM7QUFFRCxTQUFTLGdCQUFnQixDQUFDLEVBQUU7O0lBQ3hCLEtBQUksSUFBSSxLQUFLLElBQUksUUFBUSxDQUFDLE1BQU0sRUFBQztRQUM3QixLQUFJLElBQUksTUFBTSxVQUFJLEtBQUssQ0FBQyxPQUFPLG1DQUFJLEVBQUUsRUFBQztZQUNsQyxJQUFHLE1BQU0sQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFDO2dCQUNmLE9BQU8sTUFBTSxDQUFBO2FBQ2hCO1NBQ0o7S0FDSjtJQUNELE9BQU8sSUFBSSxDQUFBO0FBQ2YsQ0FBQztBQUVELFNBQVMsa0JBQWtCLENBQUMsSUFBSTs7SUFDNUIsS0FBSSxJQUFJLEtBQUssSUFBSSxRQUFRLENBQUMsTUFBTSxFQUFDO1FBQzdCLEtBQUksSUFBSSxNQUFNLFVBQUksS0FBSyxDQUFDLE9BQU8sbUNBQUksRUFBRSxFQUFDO1lBQ2xDLElBQUcsTUFBTSxDQUFDLElBQUksSUFBSSxJQUFJLEVBQUM7Z0JBQ25CLE9BQU8sTUFBTSxDQUFBO2FBQ2hCO1NBQ0o7S0FDSjtJQUNELE9BQU8sSUFBSSxDQUFBO0FBQ2YsQ0FBQztBQzdLRCw2Q0FBNkM7QUFFN0Msc0JBQXNCO0FBQ3RCLHlDQUF5QztBQUN6QyxvQ0FBb0M7QUFDcEMsbUNBQW1DO0FBRW5DLFNBQVMsVUFBVTtJQUNmLGlCQUFpQixFQUFFLENBQUE7SUFDbkIsYUFBYSxFQUFFLENBQUE7SUFDZiw2REFBNkQ7SUFDN0QsSUFBSSxLQUFLLEdBQUcsSUFBSSxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUE7SUFDekIsaUJBQWlCLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxFQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsRUFBQyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLEVBQUMsRUFBRSxFQUFDLENBQUMsQ0FBQyxDQUFBO0lBQ3RILElBQUksTUFBTSxHQUFHLFVBQVUsRUFBRSxDQUFBO0lBQ3pCLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLENBQUMsQ0FBQyxHQUFHLEVBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUMsS0FBSyxFQUFDLENBQUMsRUFBQyxFQUFFLENBQUMsQ0FBQTtJQUM1RSxTQUFTLEVBQUUsQ0FBQTtJQUVYLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxNQUFNLENBQUM7UUFDcEIsUUFBUSxDQUFDLElBQUk7WUFDVCxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFDLENBQUMsQ0FBQyxDQUFBO1FBQ3JDLENBQUM7S0FDSixDQUFDLENBQUMsQ0FBQTtBQUNQLENBQUM7QUFJRCxTQUFTLFVBQVU7SUFDZixJQUFJLEdBQUcsR0FBbUIsRUFBRSxDQUFBO0lBQzVCLElBQUksTUFBTSxHQUFHLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxDQUFBO0lBQ3ZDLEtBQUksSUFBSSxNQUFNLElBQUksTUFBTSxFQUFDO1FBQ3JCLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxNQUFNLENBQVE7WUFDM0IsSUFBSSxFQUFDLE9BQU87WUFDWixHQUFHLEVBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUU7WUFDbEIsSUFBSSxFQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsRUFBQyxJQUFJLE1BQU0sQ0FBQyxFQUFFLEVBQUMsRUFBRSxDQUFDLENBQUM7WUFDdEQsUUFBUSxDQUFDLElBQUk7Z0JBQ1QsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFBO2dCQUVuQyxJQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLEtBQUssRUFBQztvQkFDL0IsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQTtvQkFDekIsVUFBVSxDQUFDLElBQUksRUFBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFBO29CQUN0RyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQTtpQkFDNUM7Z0JBQ0QsSUFBRyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLEVBQUM7b0JBQ2pFLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFBO29CQUNqRCxJQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxJQUFJLENBQUMsRUFBQzt3QkFDdkIsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFBO3FCQUNqQjtpQkFDSjtZQUNMLENBQUM7WUFDRCxNQUFNLENBQUMsSUFBSTtnQkFDUCxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUE7Z0JBQ3ZDLElBQUksS0FBSyxHQUFHLFNBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQTtnQkFFMUMsSUFBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsR0FBRyxJQUFJLEVBQUM7b0JBQ25DLGFBQWEsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFDLHFCQUFxQixFQUFDLElBQUksRUFBQyxLQUFLLEVBQUMsSUFBSSxDQUFDLENBQUE7aUJBQ2hFO3FCQUFJO29CQUNELGFBQWEsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFDLHFCQUFxQixFQUFDLElBQUksRUFBQyxLQUFLLEVBQUMsSUFBSSxDQUFDLENBQUE7aUJBQ2hFO1lBQ0wsQ0FBQztZQUNELElBQUksRUFBQyxJQUFJLEtBQUssQ0FBQztnQkFDWCxNQUFNLEVBQUMsTUFBTTtnQkFDYixLQUFLLEVBQUMsTUFBTTtnQkFDWixNQUFNLEVBQUMsUUFBUTtnQkFDZixTQUFTLEVBQUMsSUFBSSxNQUFNLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQzthQUM1QixDQUFDO1NBQ0wsQ0FBQyxDQUFDLENBQUE7UUFDSCxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFBO0tBQzFCO0lBQ0QsT0FBTyxHQUFHLENBQUE7QUFDZCxDQUFDO0FDdkVELDBCQUEwQjtBQUUxQixTQUFTLFVBQVU7SUFDZixNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsR0FBRyxJQUFJLEdBQUcsQ0FBQztRQUN0QixJQUFJLEVBQUMsVUFBVTtRQUNmLFFBQVEsRUFBQyxNQUFNO0tBQ2xCLENBQUMsQ0FBQTtJQUNGLGlCQUFpQixFQUFFLENBQUE7SUFDbkIsYUFBYSxFQUFFLENBQUE7SUFDZixJQUFJLE1BQU0sR0FBRyxVQUFVLEVBQUUsQ0FBQTtJQUN6QixLQUFJLElBQUksS0FBSyxJQUFJLE1BQU0sRUFBQztRQUNwQixLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUMsQ0FBQyxDQUFDLENBQUE7S0FDakM7SUFDRCxRQUFRLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDLENBQUMsR0FBRyxFQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksRUFBQyxLQUFLLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFBO0lBQzFFLGlCQUFpQixDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsRUFBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLEVBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFDLEVBQUUsRUFBQyxDQUFDLENBQUMsQ0FBQTtJQUN0SCxTQUFTLEVBQUUsQ0FBQTtBQUNmLENBQUM7QUNuQkQsU0FBUyxhQUFhO0lBQ2xCLGlCQUFpQixFQUFFLENBQUE7SUFDbkIsYUFBYSxFQUFFLENBQUE7SUFDZixJQUFJLE1BQU0sR0FBRyxVQUFVLEVBQUUsQ0FBQTtJQUN6Qiw2REFBNkQ7SUFDN0QsK0VBQStFO0lBQy9FLHlIQUF5SDtJQUN6SCxJQUFJLEtBQUssR0FBRyxTQUFTLEVBQUUsQ0FBQTtJQUN2QixJQUFHLGlCQUFpQixJQUFJLEtBQUssRUFBQztRQUMxQixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUE7UUFDVCxLQUFJLElBQUksSUFBSSxJQUFJLEtBQUssRUFBQztZQUNsQixJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUE7WUFDM0IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEdBQUcsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFBO1lBQ3BDLENBQUMsRUFBRSxDQUFBO1NBQ047S0FDSjtBQUNMLENBQUM7QUNoQkQsU0FBUyxpQkFBaUI7SUFDdEIsaUJBQWlCLEVBQUUsQ0FBQTtJQUNuQixhQUFhLEVBQUUsQ0FBQTtJQUNmLFNBQVMsRUFBRSxDQUFBO0FBRWYsQ0FBQztBQ0xELDhDQUE4QztBQUM5QywwQ0FBMEM7QUFDMUMsNENBQTRDO0FBQzVDLDRDQUE0QztBQUM1Qyw0Q0FBNEM7QUFDNUMsZ0RBQWdEO0FBQ2hELDhDQUE4QztBQUM5QywyQ0FBMkM7QUFDM0MsMENBQTBDO0FBQzFDLGlEQUFpRDtBQUNqRCxrREFBa0Q7QUFDbEQsNkNBQTZDO0FBQzdDLGtEQUFrRDtBQUNsRCxrREFBa0Q7QUFDbEQsK0NBQStDO0FBQy9DLHFDQUFxQztBQUNyQyxtQ0FBbUM7QUFDbkMscUNBQXFDO0FBQ3JDLHdDQUF3QztBQUN4QyxtQ0FBbUM7QUFDbkMsc0NBQXNDO0FBQ3RDLHlDQUF5QztBQUN6QyxzQ0FBc0M7QUFDdEMscUNBQXFDO0FBQ3JDLHNDQUFzQztBQUN0QyxzQ0FBc0M7QUFDdEMsc0NBQXNDO0FBQ3RDLHlDQUF5QztBQUN6Qyw2Q0FBNkM7QUFJN0MsTUFBTTtBQUNOLHVCQUF1QjtBQUN2QiwyQ0FBMkM7QUFDM0MsbUJBQW1CO0FBQ25CLCtCQUErQjtBQUkvQixJQUFJLGlCQUFpQixHQUFHLFFBQVEsQ0FBQyxRQUFRLEtBQUssV0FBVyxDQUFBO0FBQ3pELElBQUksV0FBVyxHQUFHLFNBQVMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFBO0FBQ2xELElBQUksUUFBWSxDQUFBO0FBQ2hCLElBQUksTUFBTSxHQUFHLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBQyxRQUFRLENBQUMsTUFBTSxFQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUMsUUFBUSxDQUFDLFNBQVMsRUFBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUE7QUFDbkcsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFBO0FBQ2xCLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQTtBQUNqQyxJQUFJLGFBQWEsR0FBRyxDQUFDLElBQUksRUFBQyxLQUFLLEVBQUMsS0FBSyxDQUFDLENBQUE7QUFDdEMsS0FBSSxJQUFJLEtBQUssSUFBSSxNQUFNLEVBQUM7SUFDcEIsa0JBQWtCLENBQUMsS0FBSyxDQUFDLENBQUE7Q0FDNUI7QUFFRCxJQUFJLFVBQVUsR0FBRyxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLFdBQVcsRUFBQyxRQUFRLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQyxDQUFBO0FBQ3ZHLElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxVQUFVLENBQUMsQ0FBQyxFQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQTtBQUNuRCxJQUFJLEVBQUMsTUFBTSxFQUFDLElBQUksRUFBQyxHQUFHLEtBQUssQ0FBQTtBQUN6QixPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFBO0FBQ25CLElBQUksUUFBUSxHQUFHLElBQUksTUFBTSxDQUFDLFFBQVEsQ0FBQyxTQUFTLEVBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFBO0FBR2pFLElBQUksVUFBVSxHQUFHLElBQUksSUFBSSxDQUFDO0lBQ3RCLEdBQUcsRUFBQyxDQUFDLGtCQUFrQixDQUFDO0lBQ3hCLE1BQU0sRUFBQyxHQUFHO0NBQ2IsQ0FBQyxDQUFBO0FBQ0YsSUFBSSxVQUFVLEdBQUcsSUFBSSxJQUFJLENBQUM7SUFDdEIsR0FBRyxFQUFDLENBQUMsa0JBQWtCLENBQUM7SUFDeEIsTUFBTSxFQUFDLEdBQUc7Q0FDYixDQUFDLENBQUE7QUFDRixJQUFJLFlBQVksR0FBRyxJQUFJLElBQUksQ0FBQztJQUN4QixHQUFHLEVBQUMsQ0FBQyxvQkFBb0IsQ0FBQztJQUMxQixNQUFNLEVBQUMsR0FBRztDQUNiLENBQUMsQ0FBQTtBQUNGLElBQUksV0FBVyxHQUFHLElBQUksSUFBSSxDQUFDO0lBQ3ZCLEdBQUcsRUFBQyxDQUFDLG1CQUFtQixDQUFDO0lBQ3pCLE1BQU0sRUFBQyxHQUFHO0NBQ2IsQ0FBQyxDQUFBO0FBQ0YsSUFBSSxhQUFhLEdBQUcsSUFBSSxJQUFJLENBQUM7SUFDekIsR0FBRyxFQUFDLENBQUMscUJBQXFCLENBQUM7SUFDM0IsTUFBTSxFQUFDLENBQUM7Q0FDWCxDQUFDLENBQUE7QUFDRixJQUFJLFFBQVEsR0FBRyxJQUFJLElBQUksQ0FBQztJQUNwQixHQUFHLEVBQUMsQ0FBQyxxQkFBcUIsQ0FBQztJQUMzQixNQUFNLEVBQUMsQ0FBQztJQUNSLElBQUksRUFBQyxJQUFJO0NBQ1osQ0FBQyxDQUFBO0FBQ0YsSUFBSSxXQUFXLEdBQUcsSUFBSSxJQUFJLENBQUM7SUFDdkIsR0FBRyxFQUFDLENBQUMsd0JBQXdCLENBQUM7SUFDOUIsTUFBTSxFQUFDLENBQUM7SUFDUixJQUFJLEVBQUMsSUFBSTtDQUNaLENBQUMsQ0FBQTtBQUNGLElBQUksYUFBYSxHQUFHLElBQUksSUFBSSxDQUFDO0lBQ3pCLEdBQUcsRUFBQyxDQUFDLHFCQUFxQixDQUFDO0lBQzNCLE1BQU0sRUFBQyxDQUFDO0NBQ1gsQ0FBQyxDQUFBO0FBQ0YsSUFBSSxpQkFBaUIsR0FBRyxJQUFJLGVBQWUsQ0FBQztJQUN4QyxVQUFVLEVBQUMsU0FBUyxDQUFDLDRCQUE0QixDQUFDO0lBQ2xELFFBQVEsRUFBQyxJQUFJLE1BQU0sQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQ3hCLFNBQVMsRUFBQyxJQUFJLE1BQU0sQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQ3pCLFVBQVUsRUFBQyxDQUFDO0lBQ1osUUFBUSxFQUFDLENBQUM7SUFDVixVQUFVLEVBQUMsSUFBSSxNQUFNLENBQUMsRUFBRSxFQUFDLEVBQUUsQ0FBQztDQUMvQixDQUFDLENBQUE7QUFDRixJQUFJLGtCQUFrQixHQUFHLElBQUksZUFBZSxDQUFDO0lBQ3pDLFVBQVUsRUFBQyxTQUFTLENBQUMsNkJBQTZCLENBQUM7SUFDbkQsUUFBUSxFQUFDLElBQUksTUFBTSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFDeEIsU0FBUyxFQUFDLElBQUksTUFBTSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFDekIsVUFBVSxFQUFDLENBQUM7SUFDWixRQUFRLEVBQUMsQ0FBQztJQUNWLFVBQVUsRUFBQyxJQUFJLE1BQU0sQ0FBQyxFQUFFLEVBQUMsRUFBRSxDQUFDO0NBQy9CLENBQUMsQ0FBQTtBQUNGLElBQUksaUJBQWlCLEdBQUcsSUFBSSxlQUFlLENBQUM7SUFDeEMsVUFBVSxFQUFDLFNBQVMsQ0FBQyw0Q0FBNEMsQ0FBQztJQUNsRSxRQUFRLEVBQUMsSUFBSSxNQUFNLENBQUMsQ0FBQyxFQUFDLEVBQUUsQ0FBQztJQUN6QixTQUFTLEVBQUMsSUFBSSxNQUFNLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUN6QixVQUFVLEVBQUMsQ0FBQztJQUNaLFFBQVEsRUFBQyxHQUFHO0lBQ1osVUFBVSxFQUFDLElBQUksTUFBTSxDQUFDLEVBQUUsRUFBQyxFQUFFLENBQUM7Q0FDL0IsQ0FBQyxDQUFBO0FBQ0YsSUFBSSxxQkFBcUIsR0FBRyxJQUFJLGVBQWUsQ0FBQztJQUM1QyxVQUFVLEVBQUMsU0FBUyxDQUFDLCtCQUErQixDQUFDO0lBQ3JELFFBQVEsRUFBQyxJQUFJLE1BQU0sQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQ3hCLFNBQVMsRUFBQyxJQUFJLE1BQU0sQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQ3pCLFVBQVUsRUFBQyxFQUFFO0lBQ2IsUUFBUSxFQUFDLENBQUM7SUFDVixVQUFVLEVBQUMsSUFBSSxNQUFNLENBQUMsRUFBRSxFQUFDLEVBQUUsQ0FBQztDQUMvQixDQUFDLENBQUE7QUFDRixJQUFJLHFCQUFxQixHQUFHLElBQUksZUFBZSxDQUFDO0lBQzVDLFVBQVUsRUFBQyxTQUFTLENBQUMsK0JBQStCLENBQUM7SUFDckQsUUFBUSxFQUFDLElBQUksTUFBTSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFDeEIsU0FBUyxFQUFDLElBQUksTUFBTSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFDekIsVUFBVSxFQUFDLENBQUM7SUFDWixRQUFRLEVBQUMsQ0FBQztJQUNWLFVBQVUsRUFBQyxJQUFJLE1BQU0sQ0FBQyxFQUFFLEVBQUMsRUFBRSxDQUFDO0NBQy9CLENBQUMsQ0FBQTtBQUdGLElBQUksS0FBSyxHQUFHLEtBQUssQ0FBQTtBQUNqQixJQUFJLGdCQUFnQixHQUFHLGlCQUFpQixDQUFBO0FBRXhDLElBQUksUUFBUSxHQUFHLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUE7QUFFdEMsSUFBSSxNQUFNLEdBQUcsSUFBSSxNQUFNLENBQUM7SUFDcEIsR0FBRyxFQUFDLElBQUksTUFBTSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFDbkIsSUFBSSxFQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxNQUFNLENBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksTUFBTSxDQUFDLEVBQUUsRUFBQyxFQUFFLENBQUMsQ0FBQztJQUN0RCxJQUFJLEVBQUMsSUFBSSxNQUFNLENBQUM7UUFDWixLQUFLLEVBQUMsR0FBRztLQUVaLENBQUM7Q0FDTCxDQUFDLENBQUE7QUFDRixJQUFJLE9BQU8sR0FBaUIsRUFBRSxDQUFBO0FBQzlCLElBQUksTUFBTSxHQUFHLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFBO0FBSzdCLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRTtJQUN0QyxJQUFHLENBQUMsQ0FBQyxHQUFHLElBQUksR0FBRyxFQUFDO0tBRWY7QUFDTCxDQUFDLENBQUMsQ0FBQTtBQUVGLE1BQU0sTUFBTTtJQUFaO1FBRUksZ0JBQVcsR0FBRyxLQUFLLENBQUE7SUFDdkIsQ0FBQztDQUFBO0FBR0QsSUFBSSxZQUFZLEdBQUcsRUFBRSxDQUFBO0FBQ3JCLElBQUksbUJBQW1CLEdBQUcsRUFBRSxDQUFBO0FBRTVCLElBQUksUUFBUSxHQUFHLElBQUksTUFBTSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQTtBQUM5QixRQUFRLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxFQUFFO0lBQ3ZDLFFBQVEsR0FBRyxXQUFXLENBQUMsTUFBTSxFQUFDLENBQUMsQ0FBQyxDQUFBO0FBQ3BDLENBQUMsQ0FBQyxDQUFBO0FBQ0YsUUFBUSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsRUFBRTtJQUN2QyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFBO0lBQ3BDLFlBQVksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFBO0FBQ2pDLENBQUMsQ0FBQyxDQUFBO0FBRUYsUUFBUSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsRUFBRTtJQUNyQyxZQUFZLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEtBQUssQ0FBQTtBQUNsQyxDQUFDLENBQUMsQ0FBQTtBQUVGLElBQUksa0JBQWtCLEdBQUcsQ0FBQyxVQUFVLEVBQUMsVUFBVSxFQUFDLFVBQVUsRUFBQyxhQUFhLEVBQUMsaUJBQWlCLENBQUMsQ0FBQTtBQUUzRixrQkFBa0IsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFBO0FBQ2hDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsQ0FBQTtBQUVsQixJQUFJLFFBQVEsR0FBRyxDQUFDLENBQUM7QUFDakIsSUFBSSxJQUFJLEdBQUcsQ0FBQyxDQUFDO0FBQ2IsSUFBSSxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUU7O0lBRVIsRUFBRSxHQUFHLEtBQUssQ0FBQyxFQUFFLEVBQUMsQ0FBQyxHQUFDLEdBQUcsRUFBQyxDQUFDLEdBQUMsRUFBRSxDQUFDLENBQUE7SUFDekIsUUFBUSxHQUFHLEVBQUUsQ0FBQztJQUNkLElBQUksSUFBSSxFQUFFLENBQUM7SUFDWCxnREFBZ0Q7SUFDaEQsSUFBSSxDQUFDLFNBQVMsR0FBRyxNQUFNLENBQUE7SUFDdkIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDLFVBQVUsQ0FBQyxDQUFDLEVBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFBO0lBSTVDLElBQUksR0FBRyxHQUFHLElBQUksTUFBTSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQTtJQUV6QixJQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBQztRQUNULEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQTtLQUNWO0lBQ0QsSUFBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUM7UUFDVCxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUE7S0FDVjtJQUNELElBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFDO1FBQ1QsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFBO1FBQ1AsS0FBSyxHQUFHLElBQUksQ0FBQTtLQUNmO0lBQ0QsSUFBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUM7UUFDVCxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUE7UUFDUCxLQUFLLEdBQUcsS0FBSyxDQUFBO0tBQ2hCO0lBQ0QsSUFBRyxHQUFHLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxFQUFDO1FBQ2hCLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQTtRQUNmLGdCQUFnQixHQUFHLGlCQUFpQixDQUFBO0tBQ3ZDO1NBQUk7UUFDRCxnQkFBZ0IsR0FBRyxrQkFBa0IsQ0FBQTtLQUN4QztJQUNELFVBQVUsQ0FBQyxNQUFNLEVBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFBO0lBRXBELFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQTtJQUNoQixLQUFJLElBQUksTUFBTSxJQUFJLE9BQU8sRUFBQztRQUN0QixJQUFHLE1BQU0sQ0FBQyxpQkFBaUIsRUFBQztZQUN4QixTQUFRO1NBQ1g7UUFDRCxNQUFBLE1BQU0sQ0FBQyxRQUFRLCtDQUFmLE1BQU0sRUFBWSxNQUFNLEVBQUM7S0FDNUI7SUFDRCxPQUFPLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsSUFBSSxLQUFLLENBQUMsQ0FBQTtJQUUzRCxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUE7SUFDaEMsaUNBQWlDO0lBQ2pDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQTtJQUNWLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQTtJQUVyQixLQUFJLElBQUksTUFBTSxJQUFJLE9BQU8sRUFBQztRQUN0QixJQUFJLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQTtRQUNwQixJQUFHLE1BQU0sQ0FBQyxpQkFBaUIsRUFBQztZQUN4QixTQUFRO1NBQ1g7UUFDRCxNQUFBLE1BQU0sQ0FBQyxNQUFNLCtDQUFiLE1BQU0sRUFBVSxNQUFNLEVBQUM7S0FDMUI7SUFDRCxJQUFHLGlCQUFpQixFQUFDO1FBQ2pCLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFBO1FBQ3BCLElBQUksQ0FBQyxXQUFXLEdBQUcsU0FBUyxDQUFBO1FBQzVCLEtBQUksSUFBSSxNQUFNLElBQUksT0FBTyxFQUFDO1lBQ3RCLElBQUcsTUFBTSxDQUFDLElBQUksRUFBQztnQkFDWCxjQUFjLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFBO2FBQzlCO1NBQ0o7S0FDSjtJQUNELElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFBO0lBQ3BCLElBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFBO0lBQ3RCLElBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUM7UUFDdEIsSUFBSSxDQUFDLFdBQVcsR0FBRyxPQUFPLENBQUE7UUFDMUIsY0FBYyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQTtLQUM5QjtTQUFJO1FBQ0QsYUFBYSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUMsZ0JBQWdCLEVBQUMsSUFBSSxFQUFDLEtBQUssRUFBQyxJQUFJLENBQUMsQ0FBQTtLQUM3RDtJQUNELCtDQUErQztJQUVuRCxNQUFNLENBQUMsR0FBRyxFQUFFLENBQUE7SUFDWixtQkFBbUIsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUE7QUFDbkMsQ0FBQyxDQUFDLENBQUE7QUFFRixTQUFTLGNBQWMsQ0FBQyxJQUFTO0lBQzdCLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQTtJQUNoQixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsRUFBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQTtJQUM5QyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsRUFBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQTtJQUM5QyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsRUFBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQTtJQUM5QyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsRUFBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQTtJQUM5QyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUE7SUFDaEIsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFBO0FBQ2pCLENBQUM7QUFFRCxTQUFTLFVBQVUsQ0FBQyxNQUFrQixFQUFDLEdBQVU7SUFDN0MsSUFBSSxNQUFNLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQTtJQUMzQixJQUFHLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFDO1FBQ3hCLE9BQU07S0FDVDtJQUVELE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUE7SUFDckIsTUFBTSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFBO0lBQ3RDLElBQUcsb0JBQW9CLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFDO1FBQ2pDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUE7UUFDdkIsTUFBTSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFBO0tBQ3pDO0lBR0QsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQTtJQUNyQixNQUFNLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUE7SUFDdEMsSUFBRyxvQkFBb0IsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUM7UUFDakMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQTtRQUN2QixNQUFNLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUE7S0FDekM7QUFDTCxDQUFDIn0=