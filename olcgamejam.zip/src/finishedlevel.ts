function loadFinishedLevel(){
    movePlayerToSpawn()
    loadTeleports()
    loadFlags()
    
}